package com.thinking.machines.hr.pl.model;
import com.thinking.machines.hr.bl.manager.*;
import com.thinking.machines.hr.bl.pojo.*;
import com.thinking.machines.hr.bl.exceptions.*;
import com.thinking.machines.hr.bl.interfaces.*;
import com.thinking.machines.tmcommon.*;
import com.thinking.machines.hr.pl.exception.*;
import javax.swing.event.*;
import java.util.*;
import java.io.*;
import java.awt.*;
import javax.swing.*;
import javax.swing.table.*;
import java.io.FileOutputStream.*;
import com.itextpdf.text.pdf.*;
import com.itextpdf.text.*;
import java.net.*;
import java.text.*;
import com.itextpdf.text.Font;

class HeaderFooterManager extends PdfPageEventHelper
{
private PdfTemplate template;
private com.itextpdf.text.Image total;
public void onOpenDocument(PdfWriter writer,Document document)
{
try
{
template=writer.getDirectContent().createTemplate(50,30);
total=com.itextpdf.text.Image.getInstance(template);
total.setRole(PdfName.ARTIFACT);
}catch(BadElementException badException)
{
System.out.println(badException);
}
}
public void inStartPage(PdfWriter writer,Document document)
{
try
{
PdfPTable list=new PdfPTable(1);
list.setTotalWidth(550);
list.setLockedWidth(true);
list.getDefaultCell().setFixedHeight(20);
list.getDefaultCell().setBorder(com.itextpdf.text.Rectangle.BOTTOM);
list.getDefaultCell().setBorderColor(BaseColor.LIGHT_GRAY);
list.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
list.addCell(new Paragraph("List of Designations"));
PdfPTable header=new PdfPTable(3);
header.setWidths(new int[]{10,24,12});
header.setLockedWidth(true);
header.setTotalWidth(550);
header.getDefaultCell().setFixedHeight(40);
header.getDefaultCell().setBorder(com.itextpdf.text.Rectangle.BOTTOM);
header.getDefaultCell().setBorderColor(BaseColor.LIGHT_GRAY);
com.itextpdf.text.Image image=com.itextpdf.text.Image.getInstance("c:\\image\\logo.png");
header.addCell(image);
header.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
PdfPCell text=new PdfPCell();
text.setPaddingBottom(20);
text.setPaddingLeft(20);
text.setBorder(com.itextpdf.text.Rectangle.BOTTOM);
text.setBorderColor(BaseColor.LIGHT_GRAY);
Paragraph p1=new Paragraph("Designation Form");
p1.setAlignment(Element.ALIGN_CENTER);
text.addElement(p1);
header.addCell(text);
header.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
header.addCell(new Phrase(String.format("Page %d of 1",writer.getPageNumber())));
header.writeSelectedRows(0, -1, 34, 803, writer.getDirectContent());
list.writeSelectedRows(0,-1,34,760,writer.getDirectContent());
}catch(MalformedURLException mue)
{
System.out.println(mue);
}
catch(IOException ioe)
{
System.out.println(ioe);
}
catch(DocumentException de)
{
System.out.println(de);
}
}
public void onEndPage(PdfWriter writer,Document document)
{
PdfPTable footer=new PdfPTable(2);
footer.setTotalWidth(550);
footer.getDefaultCell().setBorder(com.itextpdf.text.Rectangle.TOP);
footer.getDefaultCell().setBorderColor(BaseColor.LIGHT_GRAY);
footer.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
footer.addCell(new Phrase("SoftWare By:Akshat Sharma"));
footer.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
footer.addCell(new Phrase(new SimpleDateFormat("dd/MM/yyyy").format(new java.util.Date())));
PdfContentByte canvas=writer.getDirectContent();
canvas.beginMarkedContentSequence(PdfName.ARTIFACT);
footer.writeSelectedRows(0,-1,34,30,canvas);
canvas.endMarkedContentSequence();
}
}
public class DesignationModel extends AbstractTableModel
{
java.util.List<DesignationInterface> list=new ArrayList<>();
private JTable table;
private String title[];
private Object data[];
private DesignationManagerInterface designationManager;
private void populateDataStructures()
{
title=new String[2];
list=designationManager.getDesignation(DesignationInterface.TITLE);
int r=getRowCount();
int c=getColumnCount();
data=new Object[r];
title[0]="S.No.";
title[1]="Designations";

int i=0;
while(i<list.size())
{
data[i]=list.get(i).getTitle();
i++;
}
}
public DesignationModel()
{
try
{
designationManager=DesignationManager.getInstance();
}catch(BLException blException)
{
System.out.println(blException.getGenericException());
}
DesignationInterface designation=new Designation();
populateDataStructures();
table=new JTable(data.length,title.length);
table.setRowHeight(table.getRowHeight() + 20);
table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
}
public int getRowCount()
{
return list.size();
}
public int getColumnCount()
{
return 2;
}
public boolean isCellEditable(int r,int c)
{
return false;
}
public String getColumnName(int columnIndex)
{
return title[columnIndex];
}
public Object getValueAt(int r,int c)
{
if(c==0) return (r+1);
return data[r];
}
public void setValueAt(Object data,int r,int c)
{
this.data[r]=data;
}
public Class getColumnClass(int c)
{
if(c==0)return Integer.class;
else
{
return String.class;
}
}
public DesignationInterface getDesignationAt(int r) throws ModelException
{
if(r<0 || r>list.size()) throw new ModelException("Invalid Index");
return list.get(r);
}
public DesignationInterface getDesignation(String designation,boolean caseSensitive,boolean partialMatch)throws ModelException
{
int found=0;
int i=0;
if(caseSensitive==false)
{
for(i=0;i<list.size();i++)
{
String d=list.get(i).getTitle().toLowerCase();
if(designation.equalsIgnoreCase(d) || d.startsWith(designation.toLowerCase()))
{
found=1;
break;
}
}
}
else
{
for(i=0;i<list.size();i++)
{
String d=list.get(i).getTitle();
if(designation.equals(d) || d.startsWith(designation))
{
found=1;
break;
}
}
}
if(found==0)
{
throw new ModelException("Invalid Designation Entered");
}
DesignationInterface clone=new Designation();
POJOCopier.copy(clone,list.get(i));
return clone;
}
public int indexOf(String title)
{
int i=0;
try
{
DesignationManagerInterface designationManager=DesignationManager.getInstance();
i=list.indexOf(designationManager.getByTitle(title));
}catch(BLException blException)
{
System.out.println(blException.getGenericException());
}
return i;
}
public int getIndexOf(DesignationInterface designation) throws ModelException
{
int found=0;
int i=0;
for(i=0;i<list.size();i++)
{
if(designation.equals(list.get(i)))
{
found=1;
break;
}
}
if(found==0)
{
throw new ModelException("Invalid Designation");
}
return i;
}
public int getIndex(String title)
{
int i=0;
try
{
i=list.indexOf(designationManager.getByTitle(title));
}
catch(BLException blException)
{
System.out.println(blException.getGenericException());
}
return i;
}
public void add(DesignationInterface designation)throws ModelException
{
try
{
DesignationManagerInterface designationManager=DesignationManager.getInstance();
designationManager.add(designation);
populateDataStructures();
fireTableDataChanged();
}catch(BLException blException)
{
throw new ModelException(blException.getGenericException());
}
}
public void update(DesignationInterface designation) throws ModelException
{
try
{
DesignationManagerInterface designationManager=DesignationManager.getInstance();
designationManager.update(designation);
populateDataStructures();
fireTableDataChanged();
}catch(BLException blException)
{
throw new ModelException(blException.getGenericException());
}
}
public void delete(int code)throws ModelException
{
try
{
DesignationManagerInterface designationManager=DesignationManager.getInstance();
designationManager.delete(code);
}catch(BLException blException)
{
throw new ModelException(blException.getGenericException());
}
populateDataStructures();
fireTableDataChanged();
}
public void pdfMaker(String filesName)
{
int pageSize=10;
int sNo=0;
boolean newPage=true;
Document document=new Document();
try
{
PdfWriter pdfWriter=PdfWriter.getInstance(document,new FileOutputStream(new File(filesName)));
HeaderFooterManager hfm=new HeaderFooterManager();
pdfWriter.setPageEvent(hfm);
document.setMargins(120,115,120,110);
document.setMarginMirroring(false);
document.setPageSize(PageSize.A4);
Font f=new Font(Font.FontFamily.HELVETICA,16.0f,Font.BOLD,BaseColor.RED);
Paragraph pol=new Paragraph("S. No.");
pol.setFont(f);
pol.setAlignment(Element.ALIGN_CENTER);
Paragraph poll=new Paragraph("Designations");
poll.setFont(f);
poll.setAlignment(Element.ALIGN_CENTER);
float[] columnWidths=new float[2];
columnWidths[0]=2.0f;
columnWidths[1]=7.0f;
PdfPTable pTable=null;
document.open();
int i=0;
while(i<list.size())
{
if(newPage)
{
pTable=new PdfPTable(columnWidths);
pTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
pTable.getDefaultCell().setFixedHeight(20);
pTable.addCell(pol);
pTable.addCell(poll);
newPage=false;
}
pTable.addCell(String.valueOf(i+1));
pTable.addCell(list.get(i).getTitle());
sNo++;
i++;
if(sNo>=pageSize)
{
if(sNo<list.size())
{
document.add(pTable);
document.newPage();
newPage=true;
}
if(sNo>list.size())
{
break;
}
}
}
document.close();
}catch(DocumentException de)
{
System.out.println(de);
}
catch(IOException ioe)
{
System.out.println(ioe);
}
}
}