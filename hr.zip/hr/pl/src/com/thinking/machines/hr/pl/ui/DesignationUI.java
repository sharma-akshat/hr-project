package com.thinking.machines.hr.pl.ui;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.*;
import javax.swing.event.*;
import java.io.*;
import java.awt.Color.*;
import javax.swing.JOptionPane;
import javax.swing.JFileChooser.*;
import javax.swing.ListSelectionModel;
import com.thinking.machines.hr.pl.model.*;
import com.thinking.machines.hr.pl.exception.*;
import com.thinking.machines.hr.dl.dto.*;
import com.thinking.machines.hr.dl.interfaces.*;
import com.thinking.machines.hr.dl.dao.*;
import com.thinking.machines.hr.dl.exceptions.*;
import com.thinking.machines.tmcommon.*;
import com.thinking.machines.hr.bl.manager.*;
import com.thinking.machines.hr.bl.interfaces.*;
import com.thinking.machines.hr.bl.pojo.*;
import com.thinking.machines.hr.bl.exceptions.*;


public class DesignationUI extends JFrame implements ActionListener, ListSelectionListener, DocumentListener
{
private JLabel titleLabel;
private JLabel noteLabel;
private JLabel searchLabel;
private JLabel designationLabel;
private JLabel designationFoundLabel;
private JTextField designationFoundTextField;
private JTextField searchTextField;
private JButton searchButton;
private JButton aButton;
private JButton cButton;
private JButton eButton;
private JButton dButton;
private JButton pButton;
private Container container;
private JScrollPane jsp;
private JTable table;
private JFrame frame;
boolean viewMode=false;
DesignationModel designationModel;
public DesignationUI()
{
designationModel=new DesignationModel();
titleLabel=new JLabel("Designation Master");
noteLabel=new JLabel("Not Found");
searchLabel=new JLabel("Search");
designationLabel=new JLabel("Designation");
designationFoundLabel=new JLabel("");
designationFoundTextField=new JTextField();
searchTextField=new JTextField();
searchButton=new JButton("x");
aButton=new JButton("A");
eButton=new JButton("E");
cButton=new JButton("C");
dButton=new JButton("D");
pButton=new JButton("P");

aButton.addActionListener(this);
eButton.addActionListener(this);
cButton.addActionListener(this);
dButton.addActionListener(this);
pButton.addActionListener(this);
searchButton.addActionListener(this);

JPanel titlePanel=new JPanel();
titlePanel.add(titleLabel);
JPanel buttonsPanel=new JPanel();
buttonsPanel.add(aButton);
buttonsPanel.add(eButton);
buttonsPanel.add(cButton);
buttonsPanel.add(dButton);
buttonsPanel.add(pButton);
buttonsPanel.setBorder(BorderFactory.createLineBorder(Color.black,2));



JPanel designationPanel=new JPanel();
designationPanel.add(designationLabel);
designationPanel.add(designationFoundLabel);
designationPanel.add(designationFoundTextField);
designationPanel.add(buttonsPanel);
designationPanel.setBorder(BorderFactory.createLineBorder(Color.black,2));
setTitle("HR Automation System");
Font titleFont=new Font("Verdana",Font.BOLD,24);
titleLabel.setFont(titleFont);
Font dataFont=new Font("Times New Roman",Font.PLAIN,20);
searchLabel.setFont(dataFont);
searchTextField.setFont(dataFont);
searchTextField.getDocument().addDocumentListener(this);
designationLabel.setFont(dataFont);
designationFoundLabel.setFont(dataFont);
designationFoundTextField.setFont(dataFont);
Font noteFont=new Font("Times New Roman",Font.BOLD,12);
noteLabel.setFont(noteFont);
Color noteColor=new Color(255,0,0);
noteLabel.setForeground(noteColor);
container=getContentPane();
container.setLayout(null);



table=new JTable(designationModel);
table.setRowHeight(table.getRowHeight() + 20);
table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
table.getColumnModel().getColumn(0).setPreferredWidth(100);
table.getColumnModel().getColumn(1).setPreferredWidth(350);
table.getTableHeader().setReorderingAllowed(false);
table.getTableHeader().setResizingAllowed(false);
table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
ListSelectionModel selectedRow=table.getSelectionModel();
selectedRow.addListSelectionListener(this);


int h=500;
int w=500;
int lm=10;
int tm=0;
jsp=new JScrollPane(table,ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS,ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
titleLabel.setBounds(lm+10,tm+10,300,50);
noteLabel.setBounds(lm+10+200+10+100+50,tm+10+50+10,100,20);
searchLabel.setBounds(lm+10,tm+10+50+10+20,150,30);
searchTextField.setBounds(lm+10+150+10,tm+10+50+20+5,250,30);
searchButton.setBounds(lm+10+200+10+200+2,tm+10+50+20+5,40,30);
jsp.setBounds(lm+10,tm+10+50+10+20+5+30+20,450,200);
designationPanel.setBounds(lm+10,tm+10+50+10+20+5+30+20+200+10,450,100);
designationLabel.setBounds(lm+10+10,tm+10+50+10+20+5+30+20+200+10+10,150,30);
designationFoundLabel.setBounds(lm+10+10+150+10,tm+10+50+10+20+5+30+20+200+10+10,250,30);
designationFoundTextField.setBounds(lm+10+10+150+10,tm+10+50+10+20+5+30+20+200+10+10,250,30);
designationFoundTextField.setVisible(false);
buttonsPanel.setBounds(lm+10+10+100,tm+10+50+10+20+5+30+20+200+10+10+30+5,250,40);

container.add(titleLabel);
container.add(noteLabel);
container.add(searchLabel);
container.add(searchTextField);
container.add(searchButton);
container.add(jsp);
container.add(designationLabel);
container.add(designationFoundLabel);
container.add(designationFoundTextField);
container.add(buttonsPanel);
container.add(designationPanel);


if(table==null)
{
aButton.setEnabled(true);
eButton.setEnabled(false);
dButton.setEnabled(false);
cButton.setEnabled(false);
pButton.setEnabled(false);
searchButton.setEnabled(false);
searchTextField.setEnabled(false);
noteLabel.setVisible(false);
designationFoundLabel.setEnabled(false);
designationFoundTextField.setEnabled(false);
designationFoundTextField.setVisible(false);
designationFoundLabel.setText(null);
designationFoundTextField.setText(null);
jsp.getHorizontalScrollBar().setEnabled(false);
jsp.getVerticalScrollBar().setEnabled(false);
}
if(table!=null)
{
aButton.setEnabled(true);
eButton.setEnabled(true);
dButton.setEnabled(true);
pButton.setEnabled(true);
cButton.setEnabled(false);
searchButton.setEnabled(true);
searchTextField.setEnabled(true);
jsp.getHorizontalScrollBar().setEnabled(true);
jsp.getVerticalScrollBar().setEnabled(true);
noteLabel.setVisible(false);
designationFoundLabel.setEnabled(true);
designationFoundLabel.setVisible(true);
designationFoundTextField.setEnabled(false);
designationFoundTextField.setVisible(false);
}



setSize(w,h);
Dimension d=Toolkit.getDefaultToolkit().getScreenSize();
setDefaultCloseOperation(EXIT_ON_CLOSE);
setLocation((d.width/2)-(w/2),(d.height/2)-(h/2));
}


public void valueChanged(ListSelectionEvent ev)
{
try
{
designationFoundLabel.setText(designationModel.getDesignationAt(table.getSelectedRow()).getTitle());
}catch(ModelException me)
{
System.out.println(me.getMessage());
}
}

public void changedUpdate(DocumentEvent de)
{

}
public void removeUpdate(DocumentEvent de)
{

}
public void insertUpdate(DocumentEvent de)
{
searchDesignation();
}

public void searchDesignation()
{
DesignationInterface designation;
try
{
designation=designationModel.getDesignation(searchTextField.getText(),false,true);
int index=designationModel.getIndexOf(designation);
table.setRowSelectionInterval(index,index);
table.scrollRectToVisible(new Rectangle(table.getCellRect(index,0,true)));
}
catch(ModelException me)
{
table.clearSelection();
noteLabel.setVisible(true);
}
if(searchTextField.getText().length()==0) noteLabel.setVisible(false);
}

public void actionPerformed(ActionEvent ev)
{


if(ev.getSource()==aButton)
{
table.setRowSelectionInterval(0,0);
table.setEnabled(false);
searchTextField.setEnabled(false);
searchButton.setEnabled(false);
eButton.setEnabled(false);
dButton.setEnabled(false);
pButton.setEnabled(false);
cButton.setEnabled(true);
aButton.setText("S");
jsp.setEnabled(false);
jsp.getHorizontalScrollBar().setEnabled(false);
jsp.getVerticalScrollBar().setEnabled(false);
designationFoundTextField.setEnabled(true);
if(viewMode==false)
{
aButton.setText("S");
designationFoundTextField.setVisible(true);
designationFoundLabel.setVisible(false);
viewMode=true;
}

else
{
if(designationFoundTextField.getText().isEmpty()==true)
{
JOptionPane.showMessageDialog(frame,"Designation Required","Error",JOptionPane.ERROR_MESSAGE);
}
else
{
viewMode=false;
try
{
DesignationInterface designation=new Designation();
designation.setTitle(designationFoundTextField.getText());
designationModel.add(designation);
}catch(ModelException modelException)
{
JOptionPane.showMessageDialog(frame,modelException.getMessage(),"Error",JOptionPane.ERROR_MESSAGE);
}
searchTextField.setEnabled(true);
searchButton.setEnabled(true);
eButton.setEnabled(true);
dButton.setEnabled(true);
pButton.setEnabled(true);
cButton.setEnabled(false);
aButton.setText("A");
table.setEnabled(true);
jsp.setEnabled(true);
jsp.getHorizontalScrollBar().setEnabled(true);
jsp.getVerticalScrollBar().setEnabled(true);
designationFoundLabel.setVisible(true);
designationFoundTextField.setText("");
designationFoundTextField.setVisible(false);
designationFoundTextField.setEnabled(false);
try
{
int index=designationModel.getIndex(designationFoundTextField.getText());
table.setRowSelectionInterval(index,index);
table.scrollRectToVisible(new Rectangle(table.getCellRect(index,0,true)));
}catch(IllegalArgumentException iae)
{
System.out.println(iae);
}
viewMode=false;
}
}
}




if(ev.getSource()==cButton)
{
viewMode=false;
aButton.setEnabled(true);
aButton.setText("A");
eButton.setText("E");
eButton.setEnabled(true);
dButton.setEnabled(true);
pButton.setEnabled(true);
cButton.setEnabled(false);
searchButton.setEnabled(true);
searchTextField.setEnabled(true);
jsp.getHorizontalScrollBar().setEnabled(true);
jsp.getVerticalScrollBar().setEnabled(true);
jsp.getViewport().getView().setEnabled(true);
designationFoundLabel.setText("");
designationFoundLabel.setEnabled(true);
designationFoundTextField.setText("");
designationFoundTextField.setEnabled(false);
designationFoundLabel.setVisible(true);
designationFoundTextField.setVisible(false);
table.setEnabled(true);
table.setRowSelectionInterval(0,0);
}


if(ev.getSource()==eButton)
{
DesignationInterface designation=null;
if(table.getSelectionModel().isSelectionEmpty())
{
JOptionPane.showMessageDialog(frame,"Select a Designation  to Edit!","Error",JOptionPane.ERROR_MESSAGE);
}
else
{
try
{
designation=designationModel.getDesignationAt(table.getSelectedRow());
}catch(ModelException modelException)
{
JOptionPane.showMessageDialog(frame,modelException.getMessage(),"Error",JOptionPane.ERROR_MESSAGE);
}

aButton.setEnabled(false);
dButton.setEnabled(false);
pButton.setEnabled(false);
cButton.setEnabled(true);
searchTextField.setEnabled(false);
searchButton.setEnabled(false);
table.setEnabled(false);
noteLabel.setVisible(false);
jsp.getHorizontalScrollBar().setEnabled(false);
jsp.getVerticalScrollBar().setEnabled(false);
jsp.setEnabled(false);
designationFoundLabel.setVisible(false);
designationFoundTextField.setEnabled(true);


if(viewMode==false)
{
try
{
viewMode=true;
eButton.setText("U");
designationFoundTextField.setText(designationModel.getDesignationAt(table.getSelectedRow()).getTitle());
designationFoundTextField.setVisible(true);
}catch(ModelException modelException)
{
JOptionPane.showMessageDialog(frame,"Invalid Row Index","Error",JOptionPane.ERROR_MESSAGE);
}
}



else
{
if(designationFoundTextField.getText().length()==0 || designationFoundTextField.getText()==null)
{
JOptionPane.showMessageDialog(frame,"Please enter a valid Designation","Error!",JOptionPane.ERROR_MESSAGE);
}
else
{
eButton.setText("E");
viewMode=false;
try
{
DesignationInterface designation1=new Designation();
designation1.setTitle(designationFoundTextField.getText());
designation1.setCode(designation.getCode());
designationModel.update(designation1);
}catch(ModelException modelException)
{
JOptionPane.showMessageDialog(frame,"Title Already exists","Error!",JOptionPane.ERROR_MESSAGE);
}
aButton.setEnabled(true);
dButton.setEnabled(true);
pButton.setEnabled(true);
cButton.setEnabled(false);
jsp.getHorizontalScrollBar().setEnabled(true);
jsp.getVerticalScrollBar().setEnabled(true);
searchTextField.setEnabled(true);
searchButton.setEnabled(true);
table.setEnabled(true);
try
{
int index=designationModel.getIndex(designationFoundTextField.getText());
table.setRowSelectionInterval(index,index);
table.scrollRectToVisible(new Rectangle(table.getCellRect(index,0,true)));
}
catch(IllegalArgumentException iae)
{
System.out.println(iae);
}
noteLabel.setVisible(false);
designationFoundTextField.setText("");
designationFoundTextField.setVisible(false);
viewMode=false;
designationFoundLabel.setVisible(true);
}
}
}
}






if(ev.getSource()==dButton)
{

String titleExtracted=null;
if(table.getSelectionModel().isSelectionEmpty())
{
JOptionPane.showMessageDialog(frame,"Select a Designation to Delete!","Error",JOptionPane.ERROR_MESSAGE);
}
else
{
aButton.setEnabled(false);
eButton.setEnabled(false);
pButton.setEnabled(false);
searchButton.setEnabled(false);
searchTextField.setEnabled(false);
table.setEnabled(false);
try
{
titleExtracted=designationModel.getDesignationAt(table.getSelectedRow()).getTitle();
}
catch(ModelException modelExceptionn)
{
System.out.println(modelExceptionn);
}
String toBe="Do you want to delete "+titleExtracted+" ?";
int returnValue=JOptionPane.showConfirmDialog(frame,toBe,"Alert",JOptionPane.YES_NO_OPTION,JOptionPane.WARNING_MESSAGE);
if(returnValue==0)
{
try
{
designationModel.delete(designationModel.getDesignationAt(table.getSelectedRow()).getCode());
}
catch(ModelException modelException)
{
JOptionPane.showMessageDialog(frame,"Model Exception","Error",JOptionPane.ERROR_MESSAGE);
System.out.println(modelException.getMessage());
}
table.setRowSelectionInterval(0,0);
aButton.setText("A");
designationFoundTextField.setText("");
designationFoundTextField.setVisible(false);
designationFoundLabel.setVisible(true);
eButton.setText("U");
eButton.setEnabled(true);
aButton.setEnabled(true);
dButton.setEnabled(true);
pButton.setEnabled(true);
cButton.setEnabled(false);
searchTextField.setEnabled(true);
searchButton.setEnabled(true);
noteLabel.setVisible(false);
table.setEnabled(true);
}
if(returnValue==1)
{
jsp.setEnabled(true);
aButton.setText("A");
designationFoundTextField.setText("");
designationFoundTextField.setVisible(false);
designationFoundLabel.setVisible(true);
eButton.setText("U");
eButton.setEnabled(true);
aButton.setEnabled(true);
dButton.setEnabled(true);
pButton.setEnabled(true);
searchTextField.setEnabled(true);
searchButton.setEnabled(true);
noteLabel.setVisible(false);
table.setEnabled(true);
table.setRowSelectionInterval(0,0);
}
}
}

if(ev.getSource()==searchButton)
{
table.setRowSelectionInterval(0,0);
noteLabel.setVisible(false);
searchTextField.setText("");
}



if(ev.getSource()==pButton)
{

JFileChooser jfc=new JFileChooser();
int returnValue=jfc.showSaveDialog(null);
if(returnValue==JFileChooser.APPROVE_OPTION)
{
File file=jfc.getSelectedFile();
String fileName=file.getName();
String pathName=file.getAbsolutePath();
if(!(pathName.endsWith(".pdf")))
{
pathName=pathName+".pdf";
}
String path=pathName.substring(0,pathName.lastIndexOf("\\"));
File file1=new File(path);
if(file1.isDirectory()==false)
{
JOptionPane.showMessageDialog(frame,"Invalid Path","Error",JOptionPane.ERROR_MESSAGE);
}
else
{
if(file.exists())
{
int yN=JOptionPane.showConfirmDialog(frame,"The File Already Exists Do You Want To Override ?","Warning",JOptionPane.YES_NO_OPTION,JOptionPane.WARNING_MESSAGE);
if(yN==JOptionPane.YES_OPTION)
{
if(fileName.endsWith(".pdf")==false)
{
fileName=fileName+".pdf";
}
designationModel.pdfMaker(fileName);
JOptionPane.showMessageDialog(frame,"PDF created in"+path,"Information",JOptionPane.INFORMATION_MESSAGE);
}
}
else
{
designationModel.pdfMaker(fileName);
JOptionPane.showMessageDialog(frame,"PDF created in"+path,"Information",JOptionPane.INFORMATION_MESSAGE);
}
}
}
}


}

}