package com.thinking.machines.hr.pl.exception;
public class ModelException extends Exception
{
public ModelException(String message)
{
super(message);
}
}