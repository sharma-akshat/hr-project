import java.lang.reflect.*;
class bbb
{
public void ramu(int a,int b)
{
}
}
class psp2
{
public static void main(String gg[])
{
try
{
Class c=Class.forName("bbb");
Class params[];
params=new Class[2];
params[0]=int.class;
params[1]=int .class;
Method m=c.getMethod("ramu",params);
System.out.println(m.getName());
Class rt=m.getReturnType();
System.out.println("Return type is : "+rt.getName());
}catch(Exception e)
{
System.out.println(e);
}
}
}