import com.thinking.machines.hr.dl.interfaces.*;
import com.thinking.machines.hr.dl.exceptions.*;
import com.thinking.machines.hr.dl.dao.*;
class EmployeeCount
{
public static void main(String gg[])
{
try
{
EmployeeDAOInterface employeeDAO;
employeeDAO=new EmployeeDAO();
int cc=employeeDAO.getCount();
System.out.println("Number of employees added :"+cc);
}catch(DAOException daoException)
{
System.out.println(daoException.getMessage());
}
}
}