import com.thinking.machines.hr.dl.dao.*;
import com.thinking.machines.hr.dl.dto.*;
import com.thinking.machines.hr.dl.interfaces.*;
import com.thinking.machines.hr.dl.exceptions.*;
class DesignationGetByCode
{
public static void main(String gg[])
{
int code=Integer.parseInt(gg[0]);
try
{
DesignationDAOInterface designationDAO=new DesignationDAO();
DesignationDTOInterface designationDTO=new DesignationDTO();
designationDTO=designationDAO.getByCode(code);
String title=designationDTO.getTitle();
System.out.println("Code : "+code+" , Title : "+title);
}catch(DAOException de)
{
System.out.println(de);
}
}
}