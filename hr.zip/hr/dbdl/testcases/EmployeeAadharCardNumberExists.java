import com.thinking.machines.hr.dl.interfaces.*;
import com.thinking.machines.hr.dl.exceptions.*;
import com.thinking.machines.hr.dl.dao.*;
import com.thinking.machines.hr.dl.dto.*;
import com.thinking.machines.tmcommon.*;
import java.sql.*;
public class EmployeeAadharCardNumberExists
{
public static void main(String gg[])
{
String EmployeeAadharCardNumberExists=Keyboard.getString("Enter Aadhar Card Number: ");
try
{
System.out.println("Do Aadhar Card Number "+EmployeeAadharCardNumberExists+" Exists :"+new EmployeeDAO().aadharCardNumberExists(EmployeeAadharCardNumberExists));
}catch(DAOException daoException)
{
System.out.println(daoException.getMessage());
}
}
}