import com.thinking.machines.hr.dl.exceptions.*;
import com.thinking.machines.hr.dl.interfaces.*;
import com.thinking.machines.hr.dl.dao.*;
import com.thinking.machines.hr.dl.dto.*;
import com.thinking.machines.tmcommon.*;
import java.math.*;
import java.text.*;
import java.util.*;
import java.sql.*;
public class EmployeeGetByDateOfBirth
{
public static void main(String gg[])
{
try
{
SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/yyyy");
java.util.Date Dob=sdf.parse(Keyboard.getString("Enter Date-Of-Birth:"));
List<EmployeeDTOInterface> employee;
employee=new EmployeeDAO().getByDateOfBirth(Dob);
for(EmployeeDTOInterface emp:employee)
{
System.out.println("Employee ID :"+emp.getEmployeeId());
System.out.println("Name :"+emp.getName());
System.out.println("Designation code :"+emp.getDesignationCode());
System.out.println("Aadhar Card Number :"+emp.getAadharCardNumber());
System.out.println("Basic Salary :"+emp.getBasicSalary().toPlainString());
System.out.println("Is Indian :"+emp.isIndian());
System.out.println("Gender :"+emp.getGender());
System.out.println("PAN number :"+emp.getPANNumber());
System.out.println("----------------------------------------");
}
}catch(Exception exception)
{
System.out.println(exception.getMessage());
}
}
}