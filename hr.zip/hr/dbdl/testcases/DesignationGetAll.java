import com.thinking.machines.hr.dl.dao.*;
import com.thinking.machines.hr.dl.dto.*;
import com.thinking.machines.hr.dl.interfaces.*;
import com.thinking.machines.hr.dl.exceptions.*;
import java.util.*;
class DesignationGetAll
{
public static void main(String gg[])
{
try
{
DesignationDAOInterface designationDAO=new DesignationDAO();
List<DesignationDTOInterface> list=new ArrayList<>();
list=designationDAO.getAll();
for(int i=0;i<list.size();i++)
{
System.out.println("Title : "+list.get(i).getTitle()+", Code : "+list.get(i).getCode());
}
}catch(DAOException de)
{
System.out.println(de);
}
}
}