import com.thinking.machines.hr.dl.dao.*;
import com.thinking.machines.hr.dl.dto.*;
import com.thinking.machines.hr.dl.interfaces.*;
import com.thinking.machines.hr.dl.exceptions.*;
class DesignationGetByTitle
{
public static void main(String gg[])
{
String title=gg[0];
try
{
DesignationDAOInterface designationDAO=new DesignationDAO();
DesignationDTOInterface designationDTO=new DesignationDTO();
designationDTO=designationDAO.getByTitle(title);
int code=designationDTO.getCode();
System.out.println("Title : "+title+" , Code : "+code);
}catch(DAOException de)
{
System.out.println(de);
}
}
}