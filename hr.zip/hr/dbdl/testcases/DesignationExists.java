import com.thinking.machines.hr.dl.dao.*;
import com.thinking.machines.hr.dl.dto.*;
import com.thinking.machines.hr.dl.interfaces.*;
import com.thinking.machines.hr.dl.exceptions.*;
class DesignationExists
{
public static void main(String gg[])
{
String title=gg[0];
try
{
DesignationDAOInterface designationDAO=new DesignationDAO();
boolean there=designationDAO.exists(title);
if(there==true)System.out.println(title+" exists");
else System.out.println("Invalid designation : "+title);
}catch(DAOException de)
{
System.out.println(de);
}
}
}