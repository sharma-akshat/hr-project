import com.thinking.machines.hr.dl.dao.*;
import com.thinking.machines.hr.dl.dto.*;
import com.thinking.machines.hr.dl.interfaces.*;
import com.thinking.machines.hr.dl.exceptions.*;
class DesignationGetCount
{
public static void main(String gg[])
{
try
{
DesignationDAOInterface designationDAO=new DesignationDAO();
int count=designationDAO.getCount();
System.out.printf("Designation Table has %d records",count);
}catch(DAOException de)
{
System.out.println(de);
}
}
}