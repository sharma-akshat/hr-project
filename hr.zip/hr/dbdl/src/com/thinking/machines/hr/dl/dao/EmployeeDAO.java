package com.thinking.machines.hr.dl.dao;
import com.thinking.machines.hr.dl.interfaces.*;
import com.thinking.machines.hr.dl.exceptions.*;
import com.thinking.machines.hr.dl.dto.*;
import com.thinking.machines.hr.dl.dao.*;
import java.sql.*;
import java.util.*;
import java.math.*;
public class EmployeeDAO implements EmployeeDAOInterface
{
public void add(EmployeeDTOInterface employeeDTO)throws DAOException
{
try
{
String name=employeeDTO.getName().trim();
if(name.length()==0 || name.length()>35)throw new DAOException("Invalid Name : "+name);
long lastID=10000;
int designationCode=employeeDTO.getDesignationCode();
BigDecimal basicSalary=employeeDTO.getBasicSalary();
String gender=employeeDTO.getGender();
boolean isIndian=employeeDTO.isIndian();
java.util.Date dateOfBirth=employeeDTO.getDateOfBirth();
java.sql.Date dob=new java.sql.Date(dateOfBirth.getYear(),dateOfBirth.getMonth(),dateOfBirth.getDate());
String panNumber=employeeDTO.getPANNumber();
String aadharCardNumber=employeeDTO.getAadharCardNumber();
Connection c=DAOConnection.getConnection();
PreparedStatement ps;
ps=c.prepareStatement("select * from employee where pan_number=?");
ps.setString(1,panNumber);
ResultSet rs;
rs=ps.executeQuery();
if(rs.next())
{
rs.close();
ps.close();
c.close();
throw new DAOException("PAN Number : "+panNumber+" exists");
}
rs.close();
ps.close();
ps=c.prepareStatement("select * from employee where aadhar_card_number=?");
ps.setString(1,aadharCardNumber);
rs=ps.executeQuery();
if(rs.next())
{
rs.close();
ps.close();
c.close();
throw new DAOException("Aadhar Card Number : "+aadharCardNumber+" exists");
}
rs.close();
ps.close();
ps=c.prepareStatement("insert into employee (name,designation_code,basic_salary,date_of_birth,gender,is_indian,pan_number,aadhar_card_number) values (?,?,?,?,?,?,?,?)",Statement.RETURN_GENERATED_KEYS);
ps.setString(1,name);
ps.setInt(2,designationCode);
ps.setBigDecimal(3,basicSalary);
ps.setDate(4,dob);
ps.setString(5,gender);
ps.setBoolean(6,isIndian);
ps.setString(7,panNumber);
ps.setString(8,aadharCardNumber);
ps.executeUpdate();
rs=ps.getGeneratedKeys();
rs.next();
int employee_id=rs.getInt(1);
long newID=lastID+employee_id;
String emp=("EMP"+newID);
employeeDTO.setEmployeeId(emp);
rs.close();
ps.close();
c.close();
}catch(Exception exception)
{
throw new DAOException(exception.getMessage());
}
}
public void update(EmployeeDTOInterface employeeDTO)throws DAOException
{
String vEmployeeID=employeeDTO.getEmployeeId();
if(vEmployeeID.startsWith("EMP")==false)throw new DAOException("Invalid Employee ID : "+vEmployeeID);
String employee=vEmployeeID.substring(3);
int id=(Integer.parseInt(employee)-10000);
String vPANNumber=employeeDTO.getPANNumber();
String vAadharCardNumber=employeeDTO.getAadharCardNumber();
String vName=employeeDTO.getName();
java.util.Date vDateOfBirth=employeeDTO.getDateOfBirth();
java.sql.Date dob=new java.sql.Date(vDateOfBirth.getYear(),vDateOfBirth.getMonth(),vDateOfBirth.getDate());
int designationCode=employeeDTO.getDesignationCode();
BigDecimal vBasicSalary=employeeDTO.getBasicSalary();
String vGender=employeeDTO.getGender();
boolean vIsIndian=employeeDTO.isIndian();
try
{
Connection c=DAOConnection.getConnection();
PreparedStatement ps;
ps=c.prepareStatement("select * from employee where employee_id=?");
ps.setInt(1,id);
ResultSet rs;
rs=ps.executeQuery();
if(rs.next()==false)
{
rs.close();
ps.close();
c.close();
throw new DAOException("Employee ID : "+vEmployeeID+" does not exist");
}
rs.close();
ps.close();
ps=c.prepareStatement("select * from employee where pan_number=? and employee_id!=?");
ps.setString(1,vPANNumber);
ps.setInt(2,id);
rs=ps.executeQuery();
if(rs.next())
{
rs.close();
ps.close();
c.close();
throw new DAOException("PAN Number : "+vPANNumber+" exists");
}
rs.close();
ps.close();
ps=c.prepareStatement("select * from employee where aadhar_card_number=? and employee_id!=?");
ps.setString(1,vAadharCardNumber);
ps.setInt(2,id);
rs=ps.executeQuery();
if(rs.next())
{
rs.close();
ps.close();
c.close();
throw new DAOException("Aadhar Card Number : "+vAadharCardNumber+" exists");
}
ps=c.prepareStatement("update employee set name=?,designation_code=?,basic_salary=?,date_of_birth=?,gender=?,is_indian=?,pan_number=?,aadhar_card_number=? where employee_id=?");
ps.setString(1,vName);
ps.setInt(2,designationCode);
ps.setBigDecimal(3,vBasicSalary);
ps.setDate(4,dob);
ps.setString(5,vGender);
ps.setBoolean(6,vIsIndian);
ps.setString(7,vPANNumber);
ps.setString(8,vAadharCardNumber);
ps.setInt(9,id);
ps.executeUpdate();
ps.close();
c.close();
}catch(Exception exception)
{
throw new DAOException(exception.getMessage());
}
}
public void delete(String employeeId)throws DAOException
{
try
{
if(employeeId.startsWith("EMP")==false) throw new DAOException("Invalid Employee ID : "+employeeId);
String employeeID=employeeId.substring(3);
int id=(Integer.parseInt(employeeID)-10000);
Connection c=DAOConnection.getConnection();
PreparedStatement ps;
ps=c.prepareStatement("select * from employee where employee_id=?");
ps.setInt(1,id);
ResultSet rs;
rs=ps.executeQuery();
if(rs.next()==false)
{
rs.close();
ps.close();
c.close();
throw new DAOException("Employee ID : "+employeeId+" does not exist");
}
rs.close();
ps.close();
ps=c.prepareStatement("delete from employee where employee_id=?");
ps.setInt(1,id);
ps.executeUpdate();
ps.close();
c.close();
}catch(Exception e)
{
throw new DAOException(e.getMessage());
}
}
public EmployeeDTOInterface getByEmployeeId(String employeeId)throws DAOException
{
EmployeeDTOInterface employeeDTO;
try
{
employeeDTO=new EmployeeDTO();
if(employeeId.startsWith("EMP")==false)throw new DAOException("Invalid Employee ID : "+employeeId);
String employeeID=employeeId.substring(3);
int id=(Integer.parseInt(employeeID)-10000);
Connection c=DAOConnection.getConnection();
PreparedStatement ps;
ps=c.prepareStatement("Select * from employee where employee_id=?");
ps.setInt(1,id);
ResultSet rs;
String name;
int designationCode;
java.sql.Date dateOfBirth;
BigDecimal basicSalary;
String gender;
boolean isIndian;
String panNumber;
String aadharCardNumber;
rs=ps.executeQuery();
if(rs.next()==false)
{
rs.close();
ps.close();
c.close();
throw new DAOException("Employee Id : "+employeeId+" does not exist");
}
name=rs.getString("name").trim();
designationCode=rs.getInt("designation_code");
dateOfBirth=rs.getDate("date_of_birth");
basicSalary=rs.getBigDecimal("basic_salary");
gender=rs.getString("gender");
isIndian=rs.getBoolean("is_indian");
panNumber=rs.getString("pan_number").trim();
aadharCardNumber=rs.getString("aadhar_card_number").trim();
employeeDTO.setName(name);
employeeDTO.setDesignationCode(designationCode);
employeeDTO.setDateOfBirth(dateOfBirth);
employeeDTO.setBasicSalary(basicSalary);
if(gender.equals("M"))employeeDTO.setGender(EmployeeDTOInterface.MALE);
if(gender.equals("F"))employeeDTO.setGender(EmployeeDTOInterface.FEMALE);
employeeDTO.isIndian(isIndian);
employeeDTO.setPANNumber(panNumber);
employeeDTO.setAadharCardNumber(aadharCardNumber);
rs.close();
ps.close();
c.close();
}catch(Exception e)
{
throw new DAOException(e.getMessage());
}
return employeeDTO;
}
public EmployeeDTOInterface getByPANNumber(String panNumber)throws DAOException
{
EmployeeDTOInterface employeeDTO;
try
{
employeeDTO=new EmployeeDTO();
Connection c=DAOConnection.getConnection();
PreparedStatement ps;
ps=c.prepareStatement("select * from employee where pan_number=?");
ps.setString(1,panNumber);
ResultSet rs;
String name;
int designationCode;
java.sql.Date dateOfBirth;
BigDecimal basicSalary;
String gender;
boolean isIndian;
String employeeID;
String aadharCardNumber;
rs=ps.executeQuery();
if(rs.next()==false)
{
rs.close();
ps.close();
c.close();
throw new DAOException("PAN Number : "+panNumber+" does not exist");
}
name=rs.getString("name").trim();
designationCode=rs.getInt("designation_code");
dateOfBirth=rs.getDate("date_of_birth");
basicSalary=rs.getBigDecimal("basic_salary");
gender=rs.getString("gender");
isIndian=rs.getBoolean("is_indian");
int id=rs.getInt("employee_id");
employeeID=("EMP"+10000+id);
aadharCardNumber=rs.getString("aadhar_card_number").trim();
employeeDTO.setName(name);
employeeDTO.setDesignationCode(designationCode);
employeeDTO.setDateOfBirth(dateOfBirth);
employeeDTO.setBasicSalary(basicSalary);
if(gender.equals("M"))employeeDTO.setGender(EmployeeDTOInterface.MALE);
if(gender.equals("F"))employeeDTO.setGender(EmployeeDTOInterface.FEMALE);
employeeDTO.isIndian(isIndian);
employeeDTO.setEmployeeId(employeeID);
employeeDTO.setAadharCardNumber(aadharCardNumber);
rs.close();
ps.close();
c.close();
}catch(Exception e)
{
throw new DAOException(e.getMessage());
}
return employeeDTO;
}
public EmployeeDTOInterface getByAadharCardNumber(String aadharCardNumber)throws DAOException
{
EmployeeDTOInterface employeeDTO;
try
{
employeeDTO=new EmployeeDTO();
Connection c=DAOConnection.getConnection();
PreparedStatement ps;
ps=c.prepareStatement("select * from employee where aadhar_card_number=?");
ps.setString(1,aadharCardNumber);
ResultSet rs;
String name;
int designationCode;
java.sql.Date dateOfBirth;
BigDecimal basicSalary;
String gender;
boolean isIndian;
String employeeID;
String panNumber;
rs=ps.executeQuery();
if(rs.next()==false)
{
rs.close();
ps.close();
c.close();
throw new DAOException("Aadhar Card Number : "+aadharCardNumber+" does not exist");
}
name=rs.getString("name").trim();
designationCode=rs.getInt("designation_code");
dateOfBirth=rs.getDate("date_of_birth");
basicSalary=rs.getBigDecimal("basic_salary");
gender=rs.getString("gender");
isIndian=rs.getBoolean("is_indian");
int id=rs.getInt("employee_id");
employeeID=("EMP"+10000+id);
panNumber=rs.getString("pan_number").trim();
employeeDTO.setName(name);
employeeDTO.setDesignationCode(designationCode);
employeeDTO.setDateOfBirth(dateOfBirth);
employeeDTO.setBasicSalary(basicSalary);
if(gender.equals("M"))employeeDTO.setGender(EmployeeDTOInterface.MALE);
if(gender.equals("F"))employeeDTO.setGender(EmployeeDTOInterface.FEMALE);
employeeDTO.isIndian(isIndian);
employeeDTO.setEmployeeId(employeeID);
employeeDTO.setPANNumber(panNumber);
rs.close();
ps.close();
c.close();
}catch(Exception e)
{
throw new DAOException(e.getMessage());
}
return employeeDTO;
}
public List<EmployeeDTOInterface>getAll() throws DAOException
{
List<EmployeeDTOInterface> list;
EmployeeDTOInterface employeeDTO;
try
{
list=new ArrayList<EmployeeDTOInterface>();
Connection c=DAOConnection.getConnection();
Statement s=c.createStatement();
ResultSet rs;
rs=s.executeQuery("select * from employee");
String name;
int designationCode;
java.sql.Date dateOfBirth;
BigDecimal basicSalary;
String gender;
boolean isIndian;
String employeeID;
String panNumber;
String aadharCardNumber;
while(rs.next())
{
employeeDTO=new EmployeeDTO();
name=rs.getString("name").trim();
designationCode=rs.getInt("designation_code");
dateOfBirth=rs.getDate("date_of_birth");
basicSalary=rs.getBigDecimal("basic_salary");
gender=rs.getString("gender");
isIndian=rs.getBoolean("is_indian");
int id=rs.getInt("employee_id");
employeeID=("EMP"+(10000+id));
panNumber=rs.getString("pan_number").trim();
aadharCardNumber=rs.getString("aadhar_card_number").trim();
employeeDTO.setName(name);
employeeDTO.setDesignationCode(designationCode);
employeeDTO.setDateOfBirth(dateOfBirth);
employeeDTO.setBasicSalary(basicSalary);
if(gender.equals("M"))employeeDTO.setGender(EmployeeDTOInterface.MALE);
if(gender.equals("F"))employeeDTO.setGender(EmployeeDTOInterface.FEMALE);
employeeDTO.isIndian(isIndian);
employeeDTO.setEmployeeId(employeeID);
employeeDTO.setPANNumber(panNumber);
employeeDTO.setAadharCardNumber(aadharCardNumber);
list.add(employeeDTO);
}
rs.close();
s.close();
c.close();
}catch(Exception e)
{
throw new DAOException(e.getMessage());
}
return list;
}
public List<EmployeeDTOInterface>getByDesignation(int designationCode)throws DAOException
{
List<EmployeeDTOInterface> list;
EmployeeDTOInterface employeeDTO;
try
{
list=new ArrayList<EmployeeDTOInterface>();
employeeDTO=new EmployeeDTO();
Connection c=DAOConnection.getConnection();
PreparedStatement ps;
ps=c.prepareStatement("select * from employee where designation_code=?");
ps.setInt(1,designationCode);
ResultSet rs;
String name;
java.sql.Date dateOfBirth;
BigDecimal basicSalary;
String gender;
boolean isIndian;
String employeeID;
String panNumber;
String aadharCardNumber;
rs=ps.executeQuery();
if(rs.next()==false)
{
rs.close();
ps.close();
c.close();
throw new DAOException("Invalid code : "+designationCode+" (Note : Maybe no record present against the code)");
}

name=rs.getString("name").trim();
dateOfBirth=rs.getDate("date_of_birth");
basicSalary=rs.getBigDecimal("basic_salary");
gender=rs.getString("gender");
isIndian=rs.getBoolean("is_indian");
int id=rs.getInt("employee_id");
employeeID=("EMP"+(10000+id));
panNumber=rs.getString("pan_number").trim();
aadharCardNumber=rs.getString("aadhar_card_number").trim();
employeeDTO.setName(name);
employeeDTO.setDateOfBirth(dateOfBirth);
employeeDTO.setBasicSalary(basicSalary);
if(gender.equals("M"))employeeDTO.setGender(EmployeeDTOInterface.MALE);
if(gender.equals("F"))employeeDTO.setGender(EmployeeDTOInterface.FEMALE);
employeeDTO.isIndian(isIndian);
employeeDTO.setEmployeeId(employeeID);
employeeDTO.setPANNumber(panNumber);
employeeDTO.setAadharCardNumber(aadharCardNumber);
list.add(employeeDTO);

while(rs.next())
{
employeeDTO=new EmployeeDTO();
name=rs.getString("name").trim();
dateOfBirth=rs.getDate("date_of_birth");
basicSalary=rs.getBigDecimal("basic_salary");
gender=rs.getString("gender");
isIndian=rs.getBoolean("is_indian");
id=rs.getInt("employee_id");
employeeID=("EMP"+(10000+id));
panNumber=rs.getString("pan_number").trim();
aadharCardNumber=rs.getString("aadhar_card_number").trim();
employeeDTO.setName(name);
employeeDTO.setDateOfBirth(dateOfBirth);
employeeDTO.setBasicSalary(basicSalary);
if(gender.equals("M"))employeeDTO.setGender(EmployeeDTOInterface.MALE);
if(gender.equals("F"))employeeDTO.setGender(EmployeeDTOInterface.FEMALE);
employeeDTO.isIndian(isIndian);
employeeDTO.setEmployeeId(employeeID);
employeeDTO.setPANNumber(panNumber);
employeeDTO.setAadharCardNumber(aadharCardNumber);
list.add(employeeDTO);
}
rs.close();
ps.close();
c.close();
}catch(Exception e)
{
throw new DAOException(e.getMessage());
}
return list;
}
public List<EmployeeDTOInterface>getByDateOfBirth(java.util.Date dateOfBirth)throws DAOException
{
List<EmployeeDTOInterface> list;
EmployeeDTOInterface employeeDTO;
try
{
list=new ArrayList<EmployeeDTOInterface>();
employeeDTO=new EmployeeDTO();
java.sql.Date dob=new java.sql.Date(dateOfBirth.getYear(),dateOfBirth.getMonth(),dateOfBirth.getDate());
Connection c=DAOConnection.getConnection();
PreparedStatement ps;
ps=c.prepareStatement("select * from employee where date_of_birth=?");
ps.setDate(1,dob);
ResultSet rs;
String name;
int designationCode;
BigDecimal basicSalary;
String gender;
boolean isIndian;
String employeeID;
String panNumber;
String aadharCardNumber;
rs=ps.executeQuery();
if(rs.next()==false)
{
rs.close();
ps.close();
c.close();
throw new DAOException("No record against the Date "+dateOfBirth);
}
name=rs.getString("name").trim();
designationCode=rs.getInt("designation_code");
basicSalary=rs.getBigDecimal("basic_salary");
gender=rs.getString("gender");
isIndian=rs.getBoolean("is_indian");
int id=rs.getInt("employee_id");
employeeID=("EMP"+10000+id);
panNumber=rs.getString("pan_number").trim();
aadharCardNumber=rs.getString("aadhar_card_number").trim();
employeeDTO.setName(name);
employeeDTO.setDesignationCode(designationCode);
employeeDTO.setBasicSalary(basicSalary);
if(gender.equals("M"))employeeDTO.setGender(EmployeeDTOInterface.MALE);
if(gender.equals("F"))employeeDTO.setGender(EmployeeDTOInterface.FEMALE);
employeeDTO.isIndian(isIndian);
employeeDTO.setEmployeeId(employeeID);
employeeDTO.setPANNumber(panNumber);
employeeDTO.setAadharCardNumber(aadharCardNumber);
list.add(employeeDTO);
while(rs.next())
{
employeeDTO=new EmployeeDTO();
name=rs.getString("name").trim();
designationCode=rs.getInt("designation_code");
basicSalary=rs.getBigDecimal("basic_salary");
gender=rs.getString("gender");
isIndian=rs.getBoolean("is_indian");
id=rs.getInt("employee_id");
employeeID=("EMP"+10000+id);
panNumber=rs.getString("pan_number").trim();
aadharCardNumber=rs.getString("aadhar_card_number").trim();
employeeDTO.setName(name);
employeeDTO.setDesignationCode(designationCode);
employeeDTO.setBasicSalary(basicSalary);
if(gender.equals("M"))employeeDTO.setGender(EmployeeDTOInterface.MALE);
if(gender.equals("F"))employeeDTO.setGender(EmployeeDTOInterface.FEMALE);
employeeDTO.isIndian(isIndian);
employeeDTO.setEmployeeId(employeeID);
employeeDTO.setPANNumber(panNumber);
employeeDTO.setAadharCardNumber(aadharCardNumber);
list.add(employeeDTO);
}
rs.close();
ps.close();
c.close();
}catch(Exception e)
{
throw new DAOException(e.getMessage());
}
return list;
}
public int getCount() throws DAOException
{
int count=0;
try
{
Connection c=DAOConnection.getConnection();
Statement s=c.createStatement();
ResultSet rs;
rs=s.executeQuery("select count(*) as cnt from employee");
rs.next();
count=rs.getInt("cnt");
rs.close();
s.close();
c.close();
}catch(Exception e)
{
throw new DAOException(e.getMessage());
}
return count;
}
public boolean employeeIdExists(String employeeId)throws DAOException
{
try
{
if(employeeId.startsWith("EMP")==false) throw new DAOException("Invalid Employee ID : "+employeeId);
String employee=employeeId.substring(3);
int id=(Integer.parseInt(employee)-10000);
Connection c=DAOConnection.getConnection();
PreparedStatement ps;
ps=c.prepareStatement("select * from employee where employee_id=?");
ps.setInt(1,id);
ResultSet rs;
rs=ps.executeQuery();
if(rs.next()==false)
{
rs.close();
ps.close();
c.close();
return false;
}
rs.close();
ps.close();
c.close();
}catch(Exception e)
{
throw new DAOException(e.getMessage());
}
return true;
}
public boolean panNumberExists(String panNumber)throws DAOException
{
try
{
Connection c=DAOConnection.getConnection();
PreparedStatement ps;
ps=c.prepareStatement("select * from employee where pan_number=?");
ps.setString(1,panNumber);
ResultSet rs;
rs=ps.executeQuery();
if(rs.next()==false)
{
rs.close();
ps.close();
c.close();
return false;
}
rs.close();
ps.close();
c.close();
}catch(Exception e)
{
throw new DAOException(e.getMessage());
}
return true;
}
public boolean aadharCardNumberExists(String aadharCardNumber)throws DAOException
{
try
{
Connection c=DAOConnection.getConnection();
PreparedStatement ps;
ps=c.prepareStatement("select * from employee where aadhar_card_number=?");
ps.setString(1,aadharCardNumber);
ResultSet rs;
rs=ps.executeQuery();
if(rs.next()==false)
{
rs.close();
ps.close();
c.close();
return false;
}
rs.close();
ps.close();
c.close();
}catch(Exception e)
{
throw new DAOException(e.getMessage());
}
return true;
}
}