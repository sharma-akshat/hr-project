package com.thinking.machines.hr.dl.dao;
import com.thinking.machines.hr.dl.dao.*;
import com.thinking.machines.hr.dl.dto.*;
import com.thinking.machines.hr.dl.exceptions.*;
import com.thinking.machines.hr.dl.interfaces.*;
import java.util.*;
import java.sql.*;
public class DesignationDAO implements DesignationDAOInterface
{
public void add(DesignationDTOInterface designationDTO) throws DAOException
{
try
{
String title=designationDTO.getTitle().trim();
Connection c=DAOConnection.getConnection();
PreparedStatement ps;
ps=c.prepareStatement("select * from designation where title=?");
ps.setString(1,title);
ResultSet rs;
rs=ps.executeQuery();
if(rs.next())
{
rs.close();
ps.close();
c.close();
throw new DAOException(title+" already exist");
}
rs.close();
ps.close();
ps=c.prepareStatement("insert into designation (title) values(?)",Statement.RETURN_GENERATED_KEYS);
ps.setString(1,title);
ps.executeUpdate();
rs=ps.getGeneratedKeys();
rs.next();
int code=rs.getInt(1);
designationDTO.setCode(code);
rs.close();
ps.close();
c.close();
}catch(Exception e)
{
throw new DAOException(e.getMessage());
}
}
public void update(DesignationDTOInterface designationDTO) throws DAOException
{
int code=designationDTO.getCode();
String title=designationDTO.getTitle().trim();
try
{
Connection c=DAOConnection.getConnection();
PreparedStatement ps;
ps=c.prepareStatement("select * from designation where code=?");
ps.setInt(1,code);
ResultSet rs;
rs=ps.executeQuery();
if(rs.next()==false)
{
rs.close();
ps.close();
c.close();
throw new DAOException("Invalid code : "+code);
}
rs.close();
ps.close();
ps=c.prepareStatement("select * from designation where title=? and code!=?");
ps.setString(1,title);
ps.setInt(2,code);
rs=ps.executeQuery();
if(rs.next()==true)
{
rs.close();
ps.close();
c.close();
throw new DAOException(title+" already exist");
}
rs.close();
ps.close();
ps=c.prepareStatement("update designation set title=? where code=?");
ps.setString(1,title);
ps.setInt(2,code);
ps.executeUpdate();
ps.close();
c.close();
}catch(Exception e)
{
throw new DAOException(e.getMessage());
}
}
public void delete(int code) throws DAOException
{
try
{
Connection c=DAOConnection.getConnection();
PreparedStatement ps;
ps=c.prepareStatement("select * from designation where code=?");
ps.setInt(1,code);
ResultSet rs;
rs=ps.executeQuery();
if(rs.next()==false)
{
rs.close();
ps.close();
c.close();
throw new DAOException("Invalid code : "+code);
}
rs.close();
ps.close();
ps=c.prepareStatement("delete from designation where code=?");
ps.setInt(1,code);
ps.executeUpdate();
ps.close();
c.close();
}catch(Exception e)
{
throw new DAOException(e.getMessage());
}
}
public DesignationDTOInterface getByCode(int code) throws DAOException
{
DesignationDTOInterface designationDTO;
try
{
designationDTO=new DesignationDTO();
Connection c=DAOConnection.getConnection();
PreparedStatement ps;
ps=c.prepareStatement("select * from designation where code=?");
ps.setInt(1,code);
ResultSet rs;
rs=ps.executeQuery();
String designation;
if(rs.next()==false)
{
rs.close();
ps.close();
c.close();
throw new DAOException("Invalid code");
}
designation=rs.getString("title").trim();
designationDTO.setTitle(designation);
rs.close();
ps.close();
c.close();
}catch(Exception e)
{
throw new DAOException(e.getMessage());
}
return designationDTO;
}
public DesignationDTOInterface getByTitle(String title) throws DAOException
{
DesignationDTOInterface designationDTO;
try
{
designationDTO=new DesignationDTO();
Connection c=DAOConnection.getConnection();
PreparedStatement ps;
ps=c.prepareStatement("select * from designation where title=?");
ps.setString(1,title);
ResultSet rs;
rs=ps.executeQuery();
int code;
if(rs.next()==false)
{
rs.close();
ps.close();
c.close();
throw new DAOException("Invalid designation");
}
code=rs.getInt("code");
designationDTO.setCode(code);
rs.close();
ps.close();
c.close();
}catch(Exception e)
{
throw new DAOException(e.getMessage());
}
return designationDTO;
}
public List<DesignationDTOInterface>getAll() throws DAOException
{
List<DesignationDTOInterface> list;
DesignationDTOInterface designationDTO;
try
{
list=new ArrayList<DesignationDTOInterface>();
Connection c=DAOConnection.getConnection();
Statement s=c.createStatement();
ResultSet rs;
rs=s.executeQuery("select * from designation");
int code;
String title;
while(rs.next())
{
designationDTO=new DesignationDTO();
code=rs.getInt("code");
title=rs.getString("title");
designationDTO.setTitle(title);
designationDTO.setCode(code);
list.add(designationDTO);
}
rs.close();
s.close();
c.close();
}catch(Exception e)
{
throw new DAOException(e.getMessage());
}
return list;
}
public int getCount() throws DAOException
{
int count=0;
try
{
Connection c=DAOConnection.getConnection();
Statement s=c.createStatement();
ResultSet rs;
rs=s.executeQuery("select count(*) as cnt from designation");
rs.next();
count=rs.getInt("cnt");
rs.close();
s.close();
c.close();
}catch(Exception e)
{
throw new DAOException(e.getMessage());
}
return count;
}
public boolean exists(int code) throws DAOException
{
try
{
Connection c=DAOConnection.getConnection();
PreparedStatement ps;
ps=c.prepareStatement("select * from designation where code=?");
ps.setInt(1,code);
ResultSet rs;
rs=ps.executeQuery();
if(rs.next()==false)
{
rs.close();
ps.close();
c.close();
return false;
}
rs.close();
ps.close();
}catch(Exception e)
{
throw new DAOException(e.getMessage());
}
return true;
}
public boolean exists(String title) throws DAOException
{
try
{
Connection c=DAOConnection.getConnection();
PreparedStatement ps;
ps=c.prepareStatement("select * from designation where title=?");
ps.setString(1,title);
ResultSet rs;
rs=ps.executeQuery();
if(rs.next()==false)
{
rs.close();
ps.close();
c.close();
return false;
}
rs.close();
ps.close();
}catch(Exception e)
{
throw new DAOException(e.getMessage());
}
return true;
}
}