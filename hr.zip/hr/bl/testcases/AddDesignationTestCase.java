import com.thinking.machines.hr.bl.manager.*;
import com.thinking.machines.hr.bl.interfaces.*;
import com.thinking.machines.hr.bl.pojo.*;
import com.thinking.machines.hr.bl.exceptions.*;
import com.thinking.machines.tmcommon.*;
import java.io.*;
import java.util.*;
import com.thinking.machines.hr.dl.dto.*;
import com.thinking.machines.hr.dl.interfaces.*;
import com.thinking.machines.hr.dl.dao.*;
import com.thinking.machines.hr.dl.exceptions.*;
class AddDesignationTestCase
{
public static void main(String gg[])
{
try
{
String title=Keyboard.getString("Enter Designation : ");
DesignationManagerInterface designationManager=DesignationManager.getInstance();
DesignationInterface designation=new Designation();
designation.setTitle(title);
designationManager.add(designation);
System.out.println("Designation is  Added with code as "+designation.getCode());
}catch(BLException blException)
{
List<String> list=new ArrayList();
list=blException.getExceptions();
for(int j=0;j<list.size();j++)
System.out.println(list.get(j));
}
}
}