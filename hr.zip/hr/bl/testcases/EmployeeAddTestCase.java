import com.thinking.machines.hr.bl.interfaces.*;
import com.thinking.machines.hr.bl.manager.*;
import com.thinking.machines.hr.bl.pojo.*;
import com.thinking.machines.hr.bl.exceptions.*;
import java.util.*;
import java.text.*;
import java.math.*;
import com.thinking.machines.tmcommon.*;
import com.thinking.machines.hr.dl.interfaces.*;
import com.thinking.machines.hr.dl.dto.*;
import com.thinking.machines.hr.dl.dao.*;
import com.thinking.machines.hr.dl.exceptions.*;
class EmployeeAddTestCase
{
public static void main(String gg[])
{
try
{
SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/yyyy");
String name=Keyboard.getString("Enter Name : ");
String gender=Keyboard.getString("Gender(M/F) : ");
if(gender.equalsIgnoreCase("M")!=true && gender.equalsIgnoreCase("F")!=true)
{
throw new RuntimeException("Invalid gender :+gender");
}
String aadharCardNumber=Keyboard.getString("Enter Aadhar Card Number : ");
String panNumber=Keyboard.getString("Enter PAN Number : ");
Date dateOfBirth=sdf.parse(Keyboard.getString("Enter Date Of Birth(dd/mm/yyyy) : "));
String isIndian=Keyboard.getString("Is Indian(Y/N) : ");
if(isIndian.equalsIgnoreCase("Y")!=true && isIndian.equalsIgnoreCase("N")!=true)
throw new RuntimeException("Invalid Input"+isIndian);
boolean vIsIndian=(isIndian.equalsIgnoreCase("Y"))?true:false;
BigDecimal basicSalary=new BigDecimal(Keyboard.getString("Enter Basic Salary : "));
String title=Keyboard.getString("Enter Designation : ");
DesignationInterface designation=new Designation();
DesignationManagerInterface designationManager=DesignationManager.getInstance();
designation=designationManager.getByTitle(title);
EmployeeManagerInterface employeeManager;
employeeManager=EmployeeManager.getInstance();
EmployeeInterface employee=new Employee();
employee.setName(name);
if(gender.equalsIgnoreCase("M"))employee.setGender(EmployeeInterface.MALE);
if(gender.equalsIgnoreCase("F"))employee.setGender(EmployeeInterface.FEMALE);
employee.setAadharCardNumber(aadharCardNumber);
employee.setPANNumber(panNumber);
employee.setDateOfBirth(dateOfBirth);
employee.isIndian(vIsIndian);
employee.setBasicSalary(basicSalary);
employee.setDesignation(designation);
employeeManager.add(employee);
System.out.println("Employee added "+employee.getEmployeeID());
}catch(BLException blException)
{
System.out.println(blException.getGenericException());
}
catch(ParseException parseException)
{
System.out.println("Parse Exception");
}

}

}