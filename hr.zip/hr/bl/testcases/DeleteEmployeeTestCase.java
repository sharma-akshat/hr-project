import com.thinking.machines.hr.bl.interfaces.*;
import com.thinking.machines.hr.bl.manager.*;
import com.thinking.machines.hr.bl.pojo.*;
import com.thinking.machines.hr.bl.exceptions.*;
import com.thinking.machines.tmcommon.*;
import com.thinking.machines.hr.dl.interfaces.*;
import com.thinking.machines.hr.dl.exceptions.*;
import com.thinking.machines.hr.dl.dao.*;
import com.thinking.machines.hr.dl.dto.*;
import java.text.*;
import java.math.*;
class DeleteEmployeeTestCase
{
public static void main(String gg[])
{
try
{
String employeeID=Keyboard.getString("Enter Employee ID : ");
EmployeeManagerInterface employeeManager=EmployeeManager.getInstance();
employeeManager.delete(employeeID);
System.out.println("Employee Deleted");
}catch(BLException blException)
{
System.out.println(blException.getGenericException());
}
}

}