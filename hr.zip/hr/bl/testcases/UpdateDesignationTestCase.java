import com.thinking.machines.hr.bl.manager.*;
import com.thinking.machines.hr.bl.interfaces.*;
import com.thinking.machines.hr.bl.pojo.*;
import com.thinking.machines.hr.bl.exceptions.*;
import com.thinking.machines.hr.dl.dao.*;
import com.thinking.machines.hr.dl.interfaces.*;
import com.thinking.machines.hr.dl.dto.*;
import com.thinking.machines.hr.dl.exceptions.*;
import com.thinking.machines.tmcommon.*;
import java.util.*;
import java.io.*;
class UpdateDesignationTestCase
{
public static void main(String gg[])
{
try
{
int code=Keyboard.getInt("Enter code to be Updated : ");
String title=Keyboard.getString("Enter Designation to Update : ");
DesignationManagerInterface designationManager=DesignationManager.getInstance();
DesignationInterface designation=new Designation();
designation.setTitle(title);
designation.setCode(code);
designationManager.update(designation);
System.out.println("Updated");
}catch(BLException blException)
{
System.out.println(blException.getGenericException());
}
}
}