import com.thinking.machines.hr.bl.interfaces.*;
import com.thinking.machines.hr.bl.manager.*;
import com.thinking.machines.hr.bl.pojo.*;
import com.thinking.machines.hr.bl.exceptions.*;
import com.thinking.machines.tmcommon.*;
import java.io.*;
import java.util.*;
import com.thinking.machines.hr.dl.interfaces.*;
import com.thinking.machines.hr.dl.dto.*;
import com.thinking.machines.hr.dl.dao.*;
import com.thinking.machines.hr.dl.exceptions.*;
class GetDesignationTestCase
{
public static void main(String gg[])
{
try
{
List<DesignationInterface> designation=new LinkedList<>();
DesignationManagerInterface dm=DesignationManager.getInstance();
designation=dm.getDesignation(DesignationInterface.CODE);
for(DesignationInterface designations:designation)
{
System.out.printf("Code %d, Title %s\n",designations.getCode(),designations.getTitle());
}
}catch(BLException blException)
{
System.out.println("BLException Generated");
}

}
}