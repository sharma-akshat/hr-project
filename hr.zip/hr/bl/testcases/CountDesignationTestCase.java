import com.thinking.machines.hr.bl.exceptions.*;
import com.thinking.machines.hr.bl.pojo.*;
import com.thinking.machines.hr.bl.manager.*;
import com.thinking.machines.hr.bl.interfaces.*;
import com.thinking.machines.tmcommon.*;
import com.thinking.machines.hr.dl.exceptions.*;
import com.thinking.machines.hr.dl.dao.*;
import com.thinking.machines.hr.dl.dto.*;
import com.thinking.machines.hr.dl.interfaces.*;
import java.io.*;
import java.util.*;
class CountDesignationTestCase
{
public static void main(String gg[])
{
try
{
int count;
DesignationManagerInterface designationManager=DesignationManager.getInstance();
count=designationManager.getCount();
System.out.println("Total number of designations are "+count);
}catch(BLException blException)
{
System.out.println(blException.getMessage());
}

}

}