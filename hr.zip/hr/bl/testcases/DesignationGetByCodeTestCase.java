import com.thinking.machines.hr.bl.manager.*;
import com.thinking.machines.hr.bl.interfaces.*;
import com.thinking.machines.hr.bl.pojo.*;
import com.thinking.machines.hr.bl.exceptions.*;
import com.thinking.machines.tmcommon.*;
import com.thinking.machines.hr.dl.dao.*;
import com.thinking.machines.hr.dl.dto.*;
import com.thinking.machines.hr.dl.interfaces.*;
import com.thinking.machines.hr.dl.exceptions.*;
import java.util.*;
import java.io.*;
class DesignationGetByCodeTestCase
{
public static void main(String gg[])
{
try
{
int code=Keyboard.getInt("Enter code : ");
DesignationManagerInterface designationManager=DesignationManager.getInstance();
DesignationInterface designation=new Designation();
designation=designationManager.getByCode(code);
System.out.println(designation.getTitle());
}catch(BLException blException)
{
System.out.println(blException.getGenericException());
}

}

}