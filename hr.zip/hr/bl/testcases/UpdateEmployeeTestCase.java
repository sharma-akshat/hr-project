import com.thinking.machines.hr.bl.interfaces.*;
import com.thinking.machines.hr.bl.manager.*;
import com.thinking.machines.hr.bl.pojo.*;
import com.thinking.machines.hr.bl.exceptions.*;
import com.thinking.machines.tmcommon.*;
import com.thinking.machines.hr.dl.interfaces.*;
import com.thinking.machines.hr.dl.exceptions.*;
import com.thinking.machines.hr.dl.dao.*;
import com.thinking.machines.hr.dl.dto.*;
import java.text.*;
import java.math.*;
class UpdateEmployeeTestCase
{
public static void main(String gg[])
{
try
{
EmployeeManagerInterface employeeManager;
employeeManager=EmployeeManager.getInstance();
EmployeeInterface employee;
employee=new Employee();
String uEmployeeID=Keyboard.getString("Enter Employee ID : ");
String uName=Keyboard.getString("Enter Name : ");
String uAadharCardNumber=Keyboard.getString("Enter Aadhar Card Number : ");
String uPANNumber=Keyboard.getString("Enter PAN Number : ");
SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/yyyy");
java.util.Date uDateOfBirth=sdf.parse(Keyboard.getString("Enter date of Birth(dd/mm/yyyy) : "));
BigDecimal uBasicSalary=new BigDecimal(Keyboard.getString("Enter Basic Salary : "));
String uGender=Keyboard.getString("Enter Gender(M/F) : ");
if(uGender.equalsIgnoreCase("M")!=true && uGender.equalsIgnoreCase("F")!=true) throw new RuntimeException("Invalid Input");
if(uGender.equalsIgnoreCase("M")) employee.setGender(EmployeeInterface.MALE);
if(uGender.equalsIgnoreCase("F")) employee.setGender(EmployeeInterface.FEMALE);
boolean uIsIndian;
String indian=Keyboard.getString("Is Indian : ");
if(indian.equalsIgnoreCase("Y")!=true && indian.equalsIgnoreCase("N")!=true) throw new RuntimeException("Invalid Input");
uIsIndian=(indian.equalsIgnoreCase("Y"))?true:false;
employee.setEmployeeID(uEmployeeID);
employee.setName(uName);
employee.setAadharCardNumber(uAadharCardNumber);
employee.setPANNumber(uPANNumber);
employee.setBasicSalary(uBasicSalary);
employee.setDateOfBirth(uDateOfBirth);

DesignationInterface uDesignation;
uDesignation=new Designation();
String title=Keyboard.getString("Enter designation : ");
uDesignation.setTitle(title);
int code=Keyboard.getInt("Enter Code : ");
uDesignation.setCode(code);
employee.setDesignation(uDesignation);

employee.isIndian(uIsIndian);
employeeManager.update(employee);
System.out.println("Employee Updated");
}catch(BLException blException)
{
System.out.println(blException.getGenericException());
}
catch(ParseException parseException)
{
System.out.println(parseException.getMessage());
}
}
}