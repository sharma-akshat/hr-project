import com.thinking.machines.hr.bl.manager.*;
import com.thinking.machines.hr.bl.interfaces.*;
import com.thinking.machines.hr.bl.pojo.*;
import com.thinking.machines.hr.bl.exceptions.*;
import com.thinking.machines.tmcommon.*;
import com.thinking.machines.hr.dl.dao.*;
import com.thinking.machines.hr.dl.dto.*;
import com.thinking.machines.hr.dl.interfaces.*;
import com.thinking.machines.hr.dl.exceptions.*;
import java.util.*;
import java.io.*;
class DesignationGetByTitleTestCase
{
public static void main(String gg[])
{
try
{
String title=Keyboard.getString("Enter Designation : ");
DesignationManagerInterface designationManager=DesignationManager.getInstance();
DesignationInterface designation;
designation=designationManager.getByTitle(title);
System.out.println("Designation : "+designation.getTitle());
System.out.println("Designation Code : "+ designation.getCode());



}catch(BLException blException)
{
System.out.println("BLException Generated");
}

}

}