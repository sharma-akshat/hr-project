import com.thinking.machines.hr.bl.interfaces.*;
import com.thinking.machines.hr.bl.manager.*;
import com.thinking.machines.hr.bl.pojo.*;
import com.thinking.machines.hr.bl.exceptions.*;
import com.thinking.machines.tmcommon.*;
import com.thinking.machines.hr.dl.interfaces.*;
import com.thinking.machines.hr.dl.exceptions.*;
import com.thinking.machines.hr.dl.dao.*;
import com.thinking.machines.hr.dl.dto.*;
import java.text.*;
import java.math.*;
class GetByEmployeeIDTestCase
{
public static void main(String gg[])
{
try
{
String employeeID=Keyboard.getString("Enter employeeID : ");
EmployeeManagerInterface employeeManager=EmployeeManager.getInstance();
EmployeeInterface employee;
employee=employeeManager.getByEmployeeID(employeeID);
System.out.println(employee.getName());
System.out.println(employee.getDesignation().getTitle());
System.out.println(employee.getGender());
System.out.println(employee.isIndian());
System.out.println(employee.getBasicSalary());
System.out.println(employee.getAadharCardNumber());
System.out.println(employee.getPANNumber());
}catch(BLException blException)
{
System.out.println(blException.getGenericException());
}
}

}