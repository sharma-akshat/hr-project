import com.thinking.machines.hr.bl.interfaces.*;
import com.thinking.machines.hr.bl.pojo.*;
import com.thinking.machines.hr.bl.manager.*;
import com.thinking.machines.hr.bl.exceptions.*;
import java.util.*;
import com.thinking.machines.tmcommon.*;
import java.math.*;
import java.text.*;
import com.thinking.machines.hr.dl.interfaces.*;
import com.thinking.machines.hr.dl.dao.*;
import com.thinking.machines.hr.dl.dto.*;
import com.thinking.machines.hr.dl.exceptions.*;
class DesignationGetByDesignationTestCase
{
public static void main(String gg[])
{
try
{
SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/yyyy");
String title=Keyboard.getString("Enter designation : ");
DesignationManagerInterface designationManager=DesignationManager.getInstance();
DesignationInterface designation=designationManager.getByTitle(title);
List<EmployeeInterface> employees;
EmployeeManagerInterface employeeManager=EmployeeManager.getInstance();
EmployeeInterface employee;
employees=employeeManager.getByDesignation(designation);
Iterator<EmployeeInterface> employeeIterator=employees.iterator();
while(employeesIterator.hasNext())
{
employee=employeesIterator.next();
System.out.println("EmployeeID : "+employee.getEmployeeID());
System.out.println("Name  : "+employee.getName());
System.out.println("Designation Code : "+employee.getDesignation().getCode());
System.out.println("Designation : "+employee.getDesignation().getTitle());
System.out.println("Date Of Birth : "+sdf.format(employee.getDateOfBirth()));
System.out.println("Basic Salary : "+employee.getBasicSalary().toPlainString());
System.out.println("Gender : "+employee.getGender());
System.out.println("Is Indian : "+employee.isIndian());
system.out.println("PAN Number : "+employee.getPANNumber());
System.out.println("Aadhar Card Number : "+employee.getAadharCardNumber());


}


}catch(BLException blException)
{
System.out.println(blException.getGenericException());
}


}


}