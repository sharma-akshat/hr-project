package com.thinking.machines.hr.bl.manager;
import com.thinking.machines.tmcommon.*;
import com.thinking.machines.hr.bl.interfaces.*;
import com.thinking.machines.hr.bl.exceptions.*;
import com.thinking.machines.hr.bl.pojo.*;
import java.util.*;
import com.thinking.machines.hr.dl.interfaces.*;
import com.thinking.machines.hr.dl.exceptions.*;
import com.thinking.machines.hr.dl.dto.*;
import com.thinking.machines.hr.dl.dao.*;
public class DesignationManager implements DesignationManagerInterface
{
Map<Integer,DesignationInterface>codeWiseMap;
Map<String,DesignationInterface>titleWiseMap;
List<DesignationInterface>codeWiseOrderedList;
List<DesignationInterface>titleWiseOrderedList;
private static DesignationManagerInterface designationManager;
private DesignationManager()
{
this.designationManager=null;
}
public static DesignationManagerInterface getInstance() throws BLException
{
if(designationManager==null)
{
designationManager=new DesignationManager();
((DesignationManager)designationManager).populateDataStructures();
}
return designationManager;
}
private void populateDataStructures() throws BLException
{
codeWiseMap=new HashMap<>();
titleWiseMap=new HashMap<>();
codeWiseOrderedList=new LinkedList<>();
titleWiseOrderedList=new LinkedList<>();
try
{
DesignationDAOInterface designationDAO;
designationDAO=new DesignationDAO();
List<DesignationDTOInterface>dlDesignations=designationDAO.getAll();
DesignationInterface designation;
int code;
String title;
for(DesignationDTOInterface dlDesignation:dlDesignations)
{
designation=new Designation();
POJOCopier.copy(designation,dlDesignation);
code=designation.getCode();
title=designation.getTitle();
codeWiseMap.put(new Integer(code),designation);
titleWiseMap.put(title.toUpperCase(),designation);
codeWiseOrderedList.add(designation);
titleWiseOrderedList.add(designation);
}
Collections.sort(codeWiseOrderedList);
Collections.sort(titleWiseOrderedList,new Comparator<DesignationInterface>(){
public int compare(DesignationInterface left,DesignationInterface right)
{
String leftTitle=left.getTitle().toUpperCase();
String rightTitle=right.getTitle().toUpperCase();
return leftTitle.compareTo(rightTitle);
}
});
}catch(DAOException daoException)
{
throw new BLException(daoException.getMessage());
}
}
public void add(DesignationInterface designation)throws BLException
{
if(designation==null) return;
String title=designation.getTitle();
int code=designation.getCode();
BLException blException=new BLException();
if(code!=0)
{
blException.addException("Code","Invalid Designation Code");
}
if(title==null)
{
blException.addException("Designation","Invalid Designation");
}
if(title.trim().length()<0 || title.trim().length()>35)
{
blException.addException("Designation","Invalid Designation");
}
if(titleExists(title)==true)
{
blException.addException("Designation","Designation Exists");
}
List<String> list=new ArrayList();
list=blException.getExceptions();
for(int j=0;j<list.size();j++)
if(list.size()!=0)throw blException;
DesignationDTOInterface designationDTO=new DesignationDTO();
DesignationDAOInterface designationDAO=new DesignationDAO();
designationDTO.setTitle(title);
try
{
designationDAO.add(designationDTO);
}catch(DAOException daoException)
{
throw new BLException(daoException.getMessage());
}
DesignationInterface designation1=new Designation();
POJOCopier.copy(designation1,designation);
codeWiseMap.put(new Integer(code),designation1);
titleWiseMap.put(title.toUpperCase(),designation1);
codeWiseOrderedList.add(designation1);
titleWiseOrderedList.add(designation1);
Collections.sort(codeWiseOrderedList);
Collections.sort(titleWiseOrderedList,new Comparator<DesignationInterface>(){
public int compare(DesignationInterface left,DesignationInterface right)
{
String leftTitle=left.getTitle().toUpperCase();
String rightTitle=right.getTitle().toUpperCase();
return leftTitle.compareTo(rightTitle);
}
});
}
public void update(DesignationInterface designation)throws BLException
{
if(designation==null) return;
String title=designation.getTitle();
int code=designation.getCode();
BLException blException=new BLException();
if(code<=0) blException.addException("Code","Invalid Code");
if(codeExists(code)==false)blException.addException("Code","Code does not exists");
if(title==null)blException.addException("Designation","Title cannot be Null");
if(title.trim().length()==0 || title.trim().length()>35)blException.addException("Designation","Invalid Designation");
if(titleExists(title)==true)blException.addException("Designation","Title Already Exists");
List<String> list=new ArrayList();
list=blException.getExceptions();
for(int j=0;j<list.size();j++)
System.out.println(list.get(j));
if(list.size()!=0)throw blException;
try
{
DesignationDAOInterface designationDAO=new DesignationDAO();
DesignationDTOInterface designationDTO=new DesignationDTO();
designationDTO.setTitle(title);
designationDTO.setCode(code);
designationDAO.update(designationDTO);
}catch(DAOException daoException)
{
throw new BLException(daoException.getMessage());
}
DesignationInterface desig=new Designation();
desig=codeWiseMap.get(code);
String newTitle=desig.getTitle();
codeWiseMap.remove(code,desig);
titleWiseMap.remove(newTitle.toUpperCase(),desig);
codeWiseOrderedList.remove(desig);
titleWiseOrderedList.remove(desig);
DesignationInterface designation1=new Designation();
POJOCopier.copy(designation1,designation);
codeWiseMap.put(new Integer(code),designation1);
titleWiseMap.put(title.toUpperCase(),designation1);
codeWiseOrderedList.add(designation1);
titleWiseOrderedList.add(designation1);
Collections.sort(codeWiseOrderedList);
Collections.sort(titleWiseOrderedList,new Comparator<DesignationInterface>(){
public int compare(DesignationInterface left,DesignationInterface right)
{
String leftTitle=left.getTitle().toUpperCase();
String rightTitle=right.getTitle().toUpperCase();
return leftTitle.compareTo(rightTitle);
}
});
}
public void delete(int code)throws BLException
{
BLException blException=new BLException();
if(code==0 || code<0)blException.addException("Code","Invalid code");
if(codeExists(code)==false)blException.addException("Code","Code does not exists");
EmployeeManagerInterface employeeManager=EmployeeManager.getInstance();
if(employeeManager.isDesignationAlloted(code)==true)blException.addException("Code","Employee exists on this designation. Can't delete");
List<String> list=new ArrayList<>();
list=blException.getExceptions();
for(int j=0;j<list.size();j++)
System.out.println(list.get(j));
if(list.size()!=0)throw blException;
else
{
try
{
DesignationDAOInterface designationDAO=new DesignationDAO();
designationDAO.delete(code);
}catch(DAOException daoException)
{
throw new BLException(daoException.getMessage());
}
DesignationInterface designation=new Designation();
designation=codeWiseMap.get(code);
String title=designation.getTitle();
codeWiseMap.remove(code,designation);
titleWiseMap.remove(title.toUpperCase(),designation);
codeWiseOrderedList.remove(designation);
titleWiseOrderedList.remove(designation);
}
}
public int getCount()
{
int count;
count=0;
if(codeWiseOrderedList.size()==0)
{
count=0;
}
for(int c=0;c<codeWiseOrderedList.size();c++)
{
count++;
}
return count;
}
public List<DesignationInterface>getDesignation(DesignationInterface.ATTRIBUTE ...orderBy)
{
List<DesignationInterface> list;
DesignationInterface designation;
list=new LinkedList<>();
if(orderBy.length==0 || orderBy[0]==DesignationInterface.TITLE)
{
for(DesignationInterface d:titleWiseOrderedList)
{
designation=new Designation();
POJOCopier.copy(designation,d);
list.add(designation);
}
}
else
{
for(DesignationInterface d:codeWiseOrderedList)
{
designation=new Designation();
POJOCopier.copy(designation,d);
list.add(designation);
}
}
return list;
}
public DesignationInterface getByCode(int code)throws BLException
{
BLException blException=new BLException();
if(code<=0)blException.addException("code","Invalid Code");
if(codeExists(code)==false)blException.addException("code","Code does not exist");
List<String> list=new ArrayList<>();
list=blException.getExceptions();
for(int j=0;j<list.size();j++)
System.out.println(list.get(j));
if(list.size()!=0)throw blException;
DesignationInterface designation;
designation=codeWiseMap.get(code);
if(codeWiseMap.containsKey(code))
{
DesignationInterface desig=new Designation();
POJOCopier.copy(desig,designation);
return desig;
}
else throw new BLException("Invalid designation code : "+code);
}
public DesignationInterface getByTitle(String title)throws BLException
{
BLException blException=new BLException();
if(title==null)blException.addException("title","title cannot be null");
if(title.trim().length()<=0 || title.trim().length()>35) blException.addException("title","Invalid title");
if(titleExists(title)==false)blException.addException("title","Title does not exist");
List<String> list=new ArrayList<>();
list=blException.getExceptions();
for(int j=0;j<list.size();j++)
System.out.println(list.get(j));
if(list.size()!=0) throw blException;
DesignationInterface designation;
designation=titleWiseMap.get(title.toUpperCase());
if(titleWiseMap.containsKey(title.toUpperCase()))
{
DesignationInterface desig=new Designation();
POJOCopier.copy(desig,designation);
return desig;
}
else throw new BLException("Invalid designation title : "+title);
}
public boolean codeExists(int code)throws BLException
{
BLException blException=new BLException();
if(code<=0)blException.addException("code","Invalid code");
if(blException.hasException("code"))throw blException;
if(codeWiseMap.containsKey(code)==false)return false;
return true;
}
public boolean titleExists(String title) throws BLException
{
BLException blException=new BLException();
if(title==null)blException.addException("title","Title is null");
if(title.trim().length()<=0 || title.trim().length()>35)blException.addException("title","Invalid title");
List<String> list=new ArrayList<>();
list=blException.getExceptions();
for(int j=0;j<list.size();j++)
System.out.println(list.get(j));
if(list.size()!=0)throw blException;
if(titleWiseMap.containsKey(title.trim().toUpperCase())==false)return false;
return true;
}
public boolean isAttachedToAnEmployee(int code)throws BLException
{
try
{
EmployeeManagerInterface employeeManager=EmployeeManager.getInstance();;
if(employeeManager.isDesignationAlloted(code)==true)return true;
else return false;
}catch(BLException blException)
{
throw new RuntimeException("Invalid designation code");
}
}
public int getEmployeesCountWithDesignation(int code)throws BLException
{
int count=0;
EmployeeManagerInterface employeeManager;
employeeManager=EmployeeManager.getInstance();
boolean designationAllotted=employeeManager.isDesignationAlloted(code);
if(designationAllotted==true)
{
count=employeeManager.designationWiseCount(code);
}
return count;

}
}