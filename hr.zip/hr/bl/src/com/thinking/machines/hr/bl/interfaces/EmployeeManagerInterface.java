package com.thinking.machines.hr.bl.interfaces;
import com.thinking.machines.hr.bl.exceptions.*;
import java.util.*;
public interface EmployeeManagerInterface
{
public void add(EmployeeInterface employee) throws BLException;
public void update(EmployeeInterface employee) throws BLException;
public void delete(String employeeID)throws BLException;
public int getCount() throws BLException;
public int designationWiseCount(int code) throws BLException;
public List<EmployeeInterface>getByDateOfBirth(java.util.Date dateOfBirth) throws BLException;
public EmployeeInterface getByPANNumber(String panNumber) throws BLException;
public EmployeeInterface getByAadharCardNumber(String aadharCardNumber) throws BLException;
public EmployeeInterface getByEmployeeID(String employeeID) throws BLException;
public List<EmployeeInterface>getAll() throws BLException;
public boolean panNumberExists(String panNumber) throws BLException;
public boolean aadharCardNumberExists(String aadharCardNumber) throws BLException;
public boolean employeeIDExists(String employeeID) throws BLException;
public boolean isDesignationAlloted(int designationCode)throws BLException;
}