package com.thinking.machines.hr.bl.pojo;
import com.thinking.machines.hr.bl.interfaces.*;
import java.math.*;
public class Employee implements EmployeeInterface
{
private String employeeID;
private String name;
private java.util.Date dateOfBirth;
private BigDecimal basicSalary;
private String panNumber;
private String aadharCardNumber;
private boolean isIndian;
private String gender;
private DesignationInterface designation;
public void setEmployeeID(String employeeID)
{
this.employeeID=employeeID;
}
public String getEmployeeID()
{
return this.employeeID;
}
public void setName(String name)
{
this.name=name;
}
public String getName()
{
return this.name;
}
public void setDateOfBirth(java.util.Date dateOfBirth)
{
this.dateOfBirth=dateOfBirth;
}
public java.util.Date getDateOfBirth()
{
return this.dateOfBirth;
}
public void setGender(GENDER gender)
{
if(gender==GENDER.MALE)
{
this.gender="M";
}
if(gender==GENDER.FEMALE)
{
this.gender="F";
}
}
public String getGender()
{
return this.gender;
}
public void isIndian(boolean isIndian)
{
this.isIndian=isIndian;
}
public boolean isIndian()
{
return this.isIndian;
}
public void setPANNumber(String panNumber)
{
this.panNumber=panNumber;
}
public String getPANNumber()
{
return this.panNumber;
}
public void setAadharCardNumber(String aadharCardNumber)
{
this.aadharCardNumber=aadharCardNumber;
}
public String getAadharCardNumber()
{
return this.aadharCardNumber;
}
public void setBasicSalary(BigDecimal basicSalary)
{
this.basicSalary=basicSalary;
}
public BigDecimal getBasicSalary()
{
return this.basicSalary;
}
public void setDesignation(DesignationInterface designation)
{
this.designation=designation;
}
public DesignationInterface getDesignation()
{
return this.designation;
}
public boolean equals(Object object)
{
if(!(object instanceof EmployeeInterface)) return false;
EmployeeInterface employee=(EmployeeInterface)object;
return this.employeeID.equalsIgnoreCase(employee.getEmployeeID());
}
public int compareTo(EmployeeInterface employee)
{
return this.employeeID.toUpperCase().compareTo(employee.getEmployeeID().toUpperCase());
}
}