package com.thinking.machines.hr.bl.manager;
import com.thinking.machines.tmcommon.*;
import com.thinking.machines.hr.bl.exceptions.*;
import com.thinking.machines.hr.bl.interfaces.*;
import com.thinking.machines.hr.bl.pojo.*;
import java.util.*;
import java.math.*;
import java.io.*;
import com.thinking.machines.hr.dl.exceptions.*;
import com.thinking.machines.hr.dl.interfaces.*;
import com.thinking.machines.hr.dl.dto.*;
import com.thinking.machines.hr.dl.dao.*;
public class EmployeeManager implements EmployeeManagerInterface
{
private Map<Integer,List<EmployeeInterface>> designationWiseEmployees;
private Map<String,EmployeeInterface> employeeIdWiseEmployees;
private Map<String,EmployeeInterface> panNumberWiseEmployees;
private Map<String,EmployeeInterface> aadharCardNumberWiseEmployees;
private Map<java.util.Date,List<EmployeeInterface>> dateOfBirthWiseEmployees;
private List<EmployeeInterface> employeeList;
private static EmployeeManagerInterface employeeManager;
EmployeeManager()
{
this.employeeManager=null;
}
public static EmployeeManagerInterface getInstance() throws BLException
{
if(employeeManager==null)
{
employeeManager=new EmployeeManager();
((EmployeeManager)employeeManager).populateDataStructures();
}
return employeeManager;
}
public void populateDataStructures() throws BLException
{
designationWiseEmployees=new HashMap<>();
employeeIdWiseEmployees=new HashMap<>();
panNumberWiseEmployees=new HashMap<>();
aadharCardNumberWiseEmployees=new HashMap<>();
dateOfBirthWiseEmployees=new HashMap<>();
employeeList=new LinkedList<>();
DesignationManagerInterface designationManager;
EmployeeInterface employee;
DesignationInterface designation;
try
{
EmployeeDAOInterface employeeDAO;
employeeDAO=new EmployeeDAO();
designationManager=DesignationManager.getInstance();
List<EmployeeDTOInterface> dlemployees;
dlemployees=employeeDAO.getAll();
for(EmployeeDTOInterface dlemployee : dlemployees)
{
employee=new Employee();
int vdesignationCode=dlemployee.getDesignationCode();
String employeeId=dlemployee.getEmployeeId();
Date DateOfBirth=dlemployee.getDateOfBirth();
String PANNumber=dlemployee.getPANNumber();
String AadharCardNumber=dlemployee.getAadharCardNumber();
designation=designationManager.getByCode(vdesignationCode);
POJOCopier.copy(employee,dlemployee);
boolean IsIndian=dlemployee.isIndian();
Date vDateOfBirth=dlemployee.getDateOfBirth();
BigDecimal BasicSalary=dlemployee.getBasicSalary();
if(dlemployee.getGender()=="M" || dlemployee.getGender()=="m")
{
employee.setGender(Employee.MALE);
}
if(dlemployee.getGender()=="F" || dlemployee.getGender()=="f");
{
employee.setGender(Employee.FEMALE);
}
employee.isIndian(IsIndian);
employee.setDateOfBirth(vDateOfBirth);
employee.setBasicSalary(BasicSalary);
employee.setDesignation(designation);
int code=employee.getDesignation().getCode();
if(designationWiseEmployees.containsKey(code)==true)
{
List<EmployeeInterface> employeeList=new LinkedList<>();
employeeList=designationWiseEmployees.get(code);
employeeList.add(employee);
}
else
{
List<EmployeeInterface> list=new LinkedList<>();
list.add(employee);
designationWiseEmployees.put(code,list);
}
if(dateOfBirthWiseEmployees.containsKey(DateOfBirth)==true)
{
List<EmployeeInterface>employeeList=new LinkedList<>();
employeeList=dateOfBirthWiseEmployees.get(DateOfBirth);
employeeList.add(employee);
}
else
{
List<EmployeeInterface> list=new LinkedList<>();
list.add(employee);
dateOfBirthWiseEmployees.put(DateOfBirth,list);
}
employeeIdWiseEmployees.put(employeeId,employee);
panNumberWiseEmployees.put(PANNumber,employee);
aadharCardNumberWiseEmployees.put(AadharCardNumber,employee);
employeeList.add(employee);
}
}catch(DAOException daoException)
{
throw new BLException(daoException.getMessage());
}
}
public void add(EmployeeInterface employee) throws BLException
{
try
{
BLException exception=new BLException();
if(employee==null) exception.addException("null","Invalid employee details");
if(employee.getName()==null) exception.addException("name","Invalid name");
if(panNumberWiseEmployees.containsKey(employee.getPANNumber())==true) exception.addException("panNumber","Invalid PANNumber");
if(aadharCardNumberWiseEmployees.containsKey(employee.getAadharCardNumber())==true) exception.addException("aadhar","Invalid aadhar card number");
boolean found=false;
DesignationManagerInterface designation=DesignationManager.getInstance();
found=designation.codeExists(employee.getDesignation().getCode());
if(found==false)
exception.addException("code","Invalid Designation");
List<String> list=new ArrayList();
list=exception.getExceptions();
for(int i=0;i<list.size();i++)
System.out.println(list.get(i));
if(list.size()!=0) throw exception;

DesignationManagerInterface dm=DesignationManager.getInstance();
DesignationInterface vDesignation=dm.getByCode(employee.getDesignation().getCode());
BigDecimal basicSalary;
boolean isIndian;
String gender;

isIndian=employee.isIndian();
basicSalary=employee.getBasicSalary();
gender=employee.getGender();
EmployeeDTOInterface dlEmployee=new EmployeeDTO();
POJOCopier.copy(dlEmployee,employee);
dlEmployee.setDesignationCode(employee.getDesignation().getCode());
dlEmployee.isIndian(isIndian);
dlEmployee.setBasicSalary(basicSalary);
if(gender.equalsIgnoreCase("M"))dlEmployee.setGender(EmployeeDTOInterface.MALE);
if(gender.equalsIgnoreCase("F"))dlEmployee.setGender(EmployeeDTOInterface.FEMALE);
EmployeeDAOInterface employeeDAO=new EmployeeDAO();
employeeDAO.add(dlEmployee);
EmployeeInterface emp1=new Employee();
employee.setEmployeeID(dlEmployee.getEmployeeId());
isIndian=employee.isIndian();
basicSalary=employee.getBasicSalary();
gender=employee.getGender();
POJOCopier.copy(emp1,employee);
emp1.setDesignation(vDesignation);//
emp1.isIndian(isIndian);
emp1.setBasicSalary(basicSalary);
emp1.setEmployeeID(employee.getEmployeeID());
if(gender.equalsIgnoreCase("M")) emp1.setGender(EmployeeInterface.MALE);
if(gender.equalsIgnoreCase("F"))emp1.setGender(EmployeeInterface.FEMALE);
List<EmployeeInterface> empList=new ArrayList();
panNumberWiseEmployees.put(emp1.getPANNumber(),emp1);
aadharCardNumberWiseEmployees.put(emp1.getAadharCardNumber(),emp1);
employeeIdWiseEmployees.put(emp1.getEmployeeID(),emp1);
EmployeeInterface e=employeeIdWiseEmployees.get(emp1.getEmployeeID());
System.out.println(e.getEmployeeID());
if (designationWiseEmployees.containsKey(emp1.getDesignation().getCode()))
{
empList=designationWiseEmployees.get(emp1.getDesignation().getCode());
empList.add(emp1);
}
else
{
empList.add(emp1);
designationWiseEmployees.put(emp1.getDesignation().getCode(),empList);
}
if (dateOfBirthWiseEmployees.containsKey(emp1.getDateOfBirth()))
{
empList=dateOfBirthWiseEmployees.get(emp1.getDateOfBirth());
empList.add(emp1);
}
else
{
empList.add(emp1);
dateOfBirthWiseEmployees.put(emp1.getDateOfBirth(),empList);
}
employeeList.add(emp1);
}catch(DAOException daoException)
{
throw new BLException(daoException.getMessage());
}
}
public void update(EmployeeInterface employee) throws BLException
{
BLException exception=new BLException();
String employeeID=employee.getEmployeeID();
if(employeeIdWiseEmployees.containsKey(employeeID)==false) exception.addException("empid","Invalid employee Id");
if(employee.getName()==null) exception.addException("name","Invalid name");
if(panNumberWiseEmployees.containsKey(employee.getPANNumber())==true)
{
EmployeeInterface eee=panNumberWiseEmployees.get(employee.getPANNumber());
if(employee.getEmployeeID()!=eee.getEmployeeID()) exception.addException("pan","invalid pan number,it already exists");
}
if(aadharCardNumberWiseEmployees.containsKey(employee.getAadharCardNumber())==true)
{
EmployeeInterface eee=aadharCardNumberWiseEmployees.get(employee.getAadharCardNumber());
if(employee.getEmployeeID()!=eee.getEmployeeID()) exception.addException("aadhar","invalid aadhar card number,it already exists");
}
boolean found=false;
int designationCode=employee.getDesignation().getCode();
found=DesignationManager.getInstance().codeExists(designationCode);
if(found==false)
exception.addException("code","Invalid Designation");
List<String> list=new ArrayList();
list=exception.getExceptions();
for(int i=0;i<list.size();i++)
System.out.println(list.get(i));
if(list.size()!=0) throw exception;
try
{
DesignationManagerInterface dm=DesignationManager.getInstance();
DesignationInterface vDesignation=dm.getByCode(employee.getDesignation().getCode());
BigDecimal basicSalary;
boolean isIndian;
String gender;
isIndian=employee.isIndian();
basicSalary=employee.getBasicSalary();
gender=employee.getGender();
EmployeeDTOInterface employeeDTO=new EmployeeDTO();
POJOCopier.copy(employeeDTO,employee);
employeeDTO.setEmployeeId(employee.getEmployeeID());
employeeDTO.setDesignationCode(employee.getDesignation().getCode());
employeeDTO.isIndian(isIndian);
employeeDTO.setBasicSalary(basicSalary);
if(gender.equalsIgnoreCase("M")) employeeDTO.setGender(EmployeeDTOInterface.MALE);
if(gender.equalsIgnoreCase("F")) employeeDTO.setGender(EmployeeDTOInterface.FEMALE);
else exception.addException("gender","Invalid Input");
if(exception.hasException("gender"))throw exception;
EmployeeDAOInterface employeeDAO=new EmployeeDAO();
employeeDAO.update(employeeDTO); //data layer updated
EmployeeInterface empi=getByEmployeeID(employee.getEmployeeID());
String pan=empi.getPANNumber();
panNumberWiseEmployees.remove(pan);
String aadhar=empi.getAadharCardNumber();
aadharCardNumberWiseEmployees.remove(aadhar);
employeeIdWiseEmployees.remove(employee.getEmployeeID());
List<EmployeeInterface> empList=new ArrayList();
int code=empi.getDesignation().getCode();
empList=designationWiseEmployees.get(code);
for(int j=0;j<empList.size();j++)
{
EmployeeInterface ee=empList.get(j);
if(ee.getEmployeeID()==employee.getEmployeeID())
{
empList.remove(j);
break;
}
}
java.util.Date dob=empi.getDateOfBirth();
empList=dateOfBirthWiseEmployees.get(dob);
for(int j=0;j<empList.size();j++)
{
EmployeeInterface ee=empList.get(j);
if(ee.getEmployeeID()==employee.getEmployeeID())
{
empList.remove(j);
break;
}
}
employeeList.remove(employee);
EmployeeInterface emp1=new Employee();
isIndian=employee.isIndian();
basicSalary=employee.getBasicSalary();
gender=employee.getGender();
POJOCopier.copy(emp1,employee);
emp1.setDesignation(vDesignation);//
emp1.isIndian(isIndian);
emp1.setBasicSalary(basicSalary);
if(gender.equalsIgnoreCase("M")) emp1.setGender(EmployeeInterface.MALE);
if(gender.equalsIgnoreCase("F"))emp1.setGender(EmployeeInterface.FEMALE);
else exception.addException("gender","Invalid Input");
if(exception.hasException("gender"))throw exception;
panNumberWiseEmployees.put(emp1.getPANNumber(),emp1);
aadharCardNumberWiseEmployees.put(emp1.getAadharCardNumber(),emp1);
employeeIdWiseEmployees.put(emp1.getEmployeeID(),emp1);
if (designationWiseEmployees.containsKey(emp1.getDesignation().getCode()))
{
empList=designationWiseEmployees.get(emp1.getDesignation().getCode());
empList.add(emp1);
}
else
{
empList.add(emp1);
designationWiseEmployees.put(emp1.getDesignation().getCode(),empList);
}
if (dateOfBirthWiseEmployees.containsKey(emp1.getDateOfBirth()))
{
empList=dateOfBirthWiseEmployees.get(emp1.getDateOfBirth());
empList.add(emp1);
}
else
{
empList.add(emp1);
dateOfBirthWiseEmployees.put(emp1.getDateOfBirth(),empList);
}
employeeList.add(emp1);
}catch(DAOException daoException)
{
throw new BLException(daoException.getMessage());
}
}
public void delete(String employeeId) throws BLException
{
BLException exception=new BLException();
if(employeeId==null) exception.addException("employeeID","Employee ID can not be null");
if(employeeIDExists(employeeId)==false) exception.addException("employeeID","Employee ID does not exist");
List<String> list=new LinkedList<>();
for(int j=0;j<list.size();j++)
System.out.println(list.get(j));
if(list.size()!=0) throw exception;
try
{
EmployeeInterface employee=employeeIdWiseEmployees.get(employeeId);
EmployeeDAO employeeDAO=new EmployeeDAO();
employeeDAO.delete(employeeId);
String pan=employee.getPANNumber();
panNumberWiseEmployees.remove(pan);
String aadhar=employee.getAadharCardNumber();
aadharCardNumberWiseEmployees.remove(aadhar);
employeeIdWiseEmployees.remove(employeeId);
List<EmployeeInterface> empList=new ArrayList();
int code=employee.getDesignation().getCode();
empList=designationWiseEmployees.get(code);
for(int j=0;j<empList.size();j++)
{
EmployeeInterface ee=empList.get(j);
if(ee.getEmployeeID()==employeeId)
{
empList.remove(j);
break;
}
}
java.util.Date dob=employee.getDateOfBirth();
empList=dateOfBirthWiseEmployees.get(dob);
for(int j=0;j<empList.size();j++)
{
EmployeeInterface ee=empList.get(j);
if(ee.getEmployeeID()==employeeId)
{
empList.remove(j);
break;
}
}
System.out.println("delete complete");
}catch(DAOException daoException)
{
throw new BLException(daoException.getMessage());
}
}
public EmployeeInterface getByEmployeeID(String EmployeeId) throws BLException
{
if(employeeIDExists(EmployeeId)==false) throw new BLException("Invalid EmployeeId ");
EmployeeInterface emp=new Employee();
boolean isIndian;
String gender;
BigDecimal basicSalary;
DesignationInterface designation;
EmployeeInterface employee=employeeIdWiseEmployees.get(EmployeeId);
isIndian=employee.isIndian();
basicSalary=employee.getBasicSalary();
gender=employee.getGender();
designation=employee.getDesignation();
POJOCopier.copy(emp,employee);
emp.isIndian(isIndian);
emp.setBasicSalary(basicSalary);
emp.setDesignation(designation);
if(gender.equalsIgnoreCase("M")) emp.setGender(EmployeeInterface.MALE);
if(gender.equalsIgnoreCase("F")) emp.setGender(EmployeeInterface.FEMALE);
return emp;
}
public EmployeeInterface getByPANNumber(String panNumber) throws BLException
{
if(panNumberExists(panNumber)==false) throw new BLException("Invalid PAN Number ");
EmployeeInterface emp=new Employee();
boolean isIndian;
String gender;
BigDecimal basicSalary;
EmployeeInterface employee=panNumberWiseEmployees.get(panNumber);
isIndian=employee.isIndian();
basicSalary=employee.getBasicSalary();
gender=employee.getGender();
POJOCopier.copy(emp,employee);
emp.isIndian(isIndian);
emp.setBasicSalary(basicSalary);
if(gender.equalsIgnoreCase("M")) emp.setGender(EmployeeInterface.MALE);
if(gender.equalsIgnoreCase("F")) emp.setGender(EmployeeInterface.FEMALE);
return emp;
}
public EmployeeInterface getByAadharCardNumber(String aadharCardNumber) throws BLException
{
if(aadharCardNumberExists(aadharCardNumber)==false) throw new BLException("Invalid Aadhar Card Number ");
EmployeeInterface emp=new Employee();
boolean isIndian;
String gender;
BigDecimal basicSalary;
EmployeeInterface employee=aadharCardNumberWiseEmployees.get(aadharCardNumber);
isIndian=employee.isIndian();
basicSalary=employee.getBasicSalary();
gender=employee.getGender();
POJOCopier.copy(emp,employee);
emp.isIndian(isIndian);
emp.setBasicSalary(basicSalary);
if(gender.equalsIgnoreCase("M")) emp.setGender(EmployeeInterface.MALE);
if(gender.equalsIgnoreCase("F")) emp.setGender(EmployeeInterface.FEMALE);
return emp;
}
public List<EmployeeInterface> getAll() throws BLException
{
List<EmployeeInterface> empList=new LinkedList();
EmployeeInterface emp1;
EmployeeInterface emp2=new Employee();
boolean isIndian;
String gender;
Date dateOfBirth;
BigDecimal basicSalary;
for(int i=0;i<employeeList.size();i++)
{
emp1=employeeList.get(i);
isIndian=emp1.isIndian();
basicSalary=emp1.getBasicSalary();
gender=emp1.getGender();
POJOCopier.copy(emp2,emp1);
emp2.setEmployeeID(emp1.getEmployeeID());
emp2.isIndian(isIndian);
emp2.setBasicSalary(basicSalary);
if(gender.equalsIgnoreCase("M")) emp2.setGender(EmployeeInterface.MALE);
if(gender.equalsIgnoreCase("F")) emp2.setGender(EmployeeInterface.FEMALE);
empList.add(emp2);
}
return empList;
}
public List<EmployeeInterface> getByDesignation(DesignationInterface designation) throws  BLException
{
if(designationWiseEmployees.containsKey(designation.getCode())==false) throw new BLException("Invalid Designation ");
boolean isIndian;
String gender;
BigDecimal basicSalary;
List<EmployeeInterface> empList=new LinkedList();
List<EmployeeInterface> list=designationWiseEmployees.get(designation.getCode());
EmployeeInterface emp=new Employee();
EmployeeInterface eee;
for(int i=0;i<list.size();i++)
{
eee=list.get(i);
isIndian=eee.isIndian();
basicSalary=eee.getBasicSalary();
gender=eee.getGender();
POJOCopier.copy(emp,eee);
emp.isIndian(isIndian);
emp.setBasicSalary(basicSalary);
if(gender.equalsIgnoreCase("M")) emp.setGender(EmployeeInterface.MALE);
if(gender.equalsIgnoreCase("F")) emp.setGender(EmployeeInterface.FEMALE);
empList.add(emp);
}
return empList;
}
public List<EmployeeInterface> getByDateOfBirth(java.util.Date dateOfBirth) throws BLException
{
if(dateOfBirthWiseEmployees.containsKey(dateOfBirth)==false) throw new BLException("Invalid Date Of Birth ");
boolean isIndian;
String gender;
BigDecimal basicSalary;
List<EmployeeInterface> empList=new LinkedList();
List<EmployeeInterface> list=dateOfBirthWiseEmployees.get(dateOfBirth);
EmployeeInterface emp=new Employee();
EmployeeInterface eee;
for(int i=0;i<list.size();i++)
{
eee=list.get(i);
isIndian=eee.isIndian();
basicSalary=eee.getBasicSalary();
gender=eee.getGender();
POJOCopier.copy(emp,eee);
emp.isIndian(isIndian);
emp.setBasicSalary(basicSalary);
if(gender.equalsIgnoreCase("M")) emp.setGender(EmployeeInterface.MALE);
if(gender.equalsIgnoreCase("F")) emp.setGender(EmployeeInterface.FEMALE);
empList.add(emp);
}
return empList;
}
public int getCount() throws BLException
{
return employeeIdWiseEmployees.size();
}
public boolean employeeIDExists(String EmployeeId) throws BLException
{
return employeeIdWiseEmployees.containsKey(EmployeeId.toUpperCase());
}
public boolean panNumberExists(String panNumber) throws BLException
{
return panNumberWiseEmployees.containsKey(panNumber.toUpperCase());
}
public boolean aadharCardNumberExists(String aadharNumber) throws BLException
{
return aadharCardNumberWiseEmployees.containsKey(aadharNumber.toUpperCase());
}
public boolean isDesignationAlloted(int designationCode)
{
return designationWiseEmployees.containsKey(designationCode);
}
public int designationWiseCount(int designationCode)
{

if(designationWiseEmployees.containsKey(designationCode)==false) return 0;
List<EmployeeInterface> list=designationWiseEmployees.get(designationCode);
return list.size();
}
}